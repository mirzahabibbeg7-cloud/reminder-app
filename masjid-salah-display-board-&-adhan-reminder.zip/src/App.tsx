/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { MosqueSettings, SoundType } from './types/prayer';
import { DEFAULT_SETTINGS, loadSettings, saveSettings } from './utils/defaultSettings';
import { getHijriDate } from './utils/hijriCalendar';
import { usePrayerTimes } from './hooks/usePrayerTimes';
import { MasjidHeader } from './components/MasjidHeader';
import { NextPrayerBanner } from './components/NextPrayerBanner';
import { PrayerGrid } from './components/PrayerGrid';
import { TickerBar } from './components/TickerBar';
import { PreAdhanAlertBanner } from './components/PreAdhanAlertBanner';
import { SilencePhoneOverlay } from './components/SilencePhoneOverlay';
import { AudioUnlockPrompt } from './components/AudioUnlockPrompt';
import { SettingsModal } from './components/SettingsModal';
import { SeasonalShiftExplorerModal } from './components/SeasonalShiftExplorerModal';
import { QuickTimeEditorModal } from './components/QuickTimeEditorModal';
import { PrayerKey } from './types/prayer';

export default function App() {
  const [settings, setSettings] = useState<MosqueSettings>(loadSettings);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showSeasonalExplorer, setShowSeasonalExplorer] = useState(false);
  const [showTimeEditor, setShowTimeEditor] = useState(false);
  const [selectedPrayerToEdit, setSelectedPrayerToEdit] = useState<PrayerKey | undefined>(undefined);
  const [dismissedSalahOverlay, setDismissedSalahOverlay] = useState(false);

  // Prayer Engine & Live Clock Hook
  const {
    now,
    prayerData,
    activeAlert,
    dismissAlert,
    audioUnlocked,
    unlockAudio,
    triggerTestSound,
  } = usePrayerTimes(settings);

  // Hijri date based on today and offset
  const hijriDate = getHijriDate(now, settings.hijriOffsetDays);

  // Save settings when changed
  const handleUpdateSettings = (updated: MosqueSettings) => {
    setSettings(updated);
    saveSettings(updated);
  };

  // Toggle fullscreen mode
  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  }, []);

  // Sync fullscreen change event
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Keyboard shortcuts for Mosque Kiosk Operator
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts if typing inside an input/textarea
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;

      if (e.key === 'f' || e.key === 'F') {
        handleToggleFullscreen();
      } else if (e.key === 's' || e.key === 'S') {
        setShowSettings((prev) => !prev);
      } else if (e.key === 'm' || e.key === 'M') {
        setSettings((prev) => {
          const updated = { ...prev, soundMuted: !prev.soundMuted };
          saveSettings(updated);
          return updated;
        });
      } else if (e.key === 't' || e.key === 'T') {
        triggerTestSound();
      } else if (e.key === 'p' || e.key === 'P') {
        setShowTimeEditor((prev) => !prev);
      } else if (e.key === 'e' || e.key === 'E') {
        setShowSeasonalExplorer((prev) => !prev);
      } else if (e.key === 'Escape') {
        setShowSettings(false);
        setShowSeasonalExplorer(false);
        setShowTimeEditor(false);
        setDismissedSalahOverlay(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleToggleFullscreen, triggerTestSound]);

  // Reset dismissedSalahOverlay when leaving the salah window
  useEffect(() => {
    if (!prayerData.isInSalahWindow) {
      setDismissedSalahOverlay(false);
    }
  }, [prayerData.isInSalahWindow]);

  const handleToggleMute = () => {
    setSettings((prev) => {
      const updated = { ...prev, soundMuted: !prev.soundMuted };
      saveSettings(updated);
      return updated;
    });
  };

  const handleTestSound = (soundType?: SoundType) => {
    triggerTestSound(soundType || settings.reminders.dhuhr.soundType);
  };

  return (
    <div
      onClick={unlockAudio}
      className="min-h-screen flex flex-col justify-between bg-slate-950 text-slate-100 relative overflow-x-hidden selection:bg-amber-500/30 selection:text-amber-200"
    >
      {/* Decorative Islamic Geometric subtle background grid */}
      <div
        className="fixed inset-0 pointer-events-none opacity-[0.035]"
        style={{
          backgroundImage: `radial-gradient(circle at 25px 25px, #f59e0b 2%, transparent 0%), radial-gradient(circle at 75px 75px, #10b981 2%, transparent 0%)`,
          backgroundSize: '100px 100px',
        }}
      />

      {/* Top Header: Mosque Branding, Real-Time Digital Clock & Gregorian/Hijri Dates */}
      <MasjidHeader
        settings={settings}
        currentTime={now}
        hijriDate={hijriDate}
        audioUnlocked={audioUnlocked}
        isFullscreen={isFullscreen}
        onToggleFullscreen={handleToggleFullscreen}
        onOpenSettings={() => setShowSettings(true)}
        onOpenSeasonalExplorer={() => setShowSeasonalExplorer(true)}
        onOpenTimeEditor={() => {
          setSelectedPrayerToEdit(undefined);
          setShowTimeEditor(true);
        }}
        onToggleMute={handleToggleMute}
        onTestSound={() => handleTestSound()}
      />

      {/* Main Board View: Large Format for TV Screens & Kiosks */}
      <main className="flex-1 flex flex-col justify-center py-2 sm:py-4">
        {/* Focal Anchor: Next Prayer Call / Iqamah Countdown Banner */}
        <NextPrayerBanner
          prayerData={prayerData}
          settings={settings}
          onTestSound={() => handleTestSound()}
        />

        {/* 6-Card Main Daily Prayer Schedule (Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha) */}
        <PrayerGrid
          prayerData={prayerData}
          settings={settings}
          onEditPrayer={(key) => {
            setSelectedPrayerToEdit(key);
            setShowTimeEditor(true);
          }}
          onEditJumua={() => {
            setSelectedPrayerToEdit(undefined);
            setShowTimeEditor(true);
          }}
        />
      </main>

      {/* Bottom Announcement / Hadith Rotating Ticker & Solar Shift Indicator */}
      <TickerBar settings={settings} currentTime={now} />

      {/* Pre-Adhan Audio Chime Notification Banner */}
      {activeAlert && (
        <PreAdhanAlertBanner alert={activeAlert} onDismiss={dismissAlert} />
      )}

      {/* Full-Screen Silence Phone Congregation Mode */}
      {prayerData.isInSalahWindow && !dismissedSalahOverlay && (
        <SilencePhoneOverlay
          prayerData={prayerData}
          onDismiss={() => setDismissedSalahOverlay(true)}
        />
      )}

      {/* Audio Unlock Notice if browser blocked autoplay */}
      <AudioUnlockPrompt
        unlocked={audioUnlocked}
        onUnlock={unlockAudio}
        onTest={() => handleTestSound()}
      />

      {/* Quick Salah & Jumma Times Editor Modal */}
      {showTimeEditor && (
        <QuickTimeEditorModal
          settings={settings}
          onSave={handleUpdateSettings}
          onClose={() => {
            setShowTimeEditor(false);
            setSelectedPrayerToEdit(undefined);
          }}
          initialSelectedPrayer={selectedPrayerToEdit}
        />
      )}

      {/* Settings Modal (Reminder Bip minutes, Iqamah, Location & Methods) */}
      {showSettings && (
        <SettingsModal
          settings={settings}
          onSave={handleUpdateSettings}
          onClose={() => setShowSettings(false)}
          onTestSound={(snd) => handleTestSound(snd)}
        />
      )}

      {/* Seasonal Shift Calendar Explorer Modal */}
      {showSeasonalExplorer && (
        <SeasonalShiftExplorerModal
          settings={settings}
          onClose={() => setShowSeasonalExplorer(false)}
        />
      )}
    </div>
  );
}
