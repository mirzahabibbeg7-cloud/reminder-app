import React from 'react';
import { Volume2, Sparkles } from 'lucide-react';

interface AudioUnlockPromptProps {
  unlocked: boolean;
  onUnlock: () => void;
  onTest: () => void;
}

export const AudioUnlockPrompt: React.FC<AudioUnlockPromptProps> = ({
  unlocked,
  onUnlock,
  onTest,
}) => {
  if (unlocked) return null;

  return (
    <aside
      aria-label="Audio Reminder Notice"
      className="fixed bottom-14 inset-x-4 z-40 max-w-xl mx-auto font-bengali"
    >
      <div className="rounded-xl border border-amber-500/40 bg-slate-900/95 p-3.5 shadow-2xl backdrop-blur-md flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-amber-500/20 text-amber-300">
            <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" />
          </div>
          <div>
            <div className="font-semibold text-amber-100">
              আযান রিমাইন্ডার সাউন্ড চালু করুন
            </div>
            <div className="text-slate-400 text-[11px]">
              ব্রাউজারে নামাজের পূর্ববর্তী সতর্কবার্তা বিপ বাজার অনুমতি দিতে এখানে ক্লিক করুন।
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              onUnlock();
              onTest();
            }}
            className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>চালু ও সাউন্ড টেস্ট</span>
          </button>
        </div>
      </div>
    </aside>
  );
};
