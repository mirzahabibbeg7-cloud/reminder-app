import React from 'react';
import { MosqueSettings } from '../types/prayer';
import { HijriDateInfo, formatBengaliGregorianDate } from '../utils/hijriCalendar';
import {
  Maximize2,
  Minimize2,
  Settings,
  Volume2,
  VolumeX,
  Compass,
  Sparkles,
  Clock,
  Edit3,
} from 'lucide-react';

interface MasjidHeaderProps {
  settings: MosqueSettings;
  currentTime: Date;
  hijriDate: HijriDateInfo;
  audioUnlocked: boolean;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onOpenSettings: () => void;
  onOpenSeasonalExplorer: () => void;
  onOpenTimeEditor: () => void;
  onToggleMute: () => void;
  onTestSound: () => void;
}

export const MasjidHeader: React.FC<MasjidHeaderProps> = ({
  settings,
  currentTime,
  hijriDate,
  isFullscreen,
  onToggleFullscreen,
  onOpenSettings,
  onOpenSeasonalExplorer,
  onOpenTimeEditor,
  onToggleMute,
  onTestSound,
}) => {
  // Format current live time
  const hours = currentTime.getHours();
  const minutes = currentTime.getMinutes().toString().padStart(2, '0');
  const seconds = currentTime.getSeconds().toString().padStart(2, '0');

  const is12h = settings.timeFormat === '12h';
  const displayHours = is12h ? (hours % 12 === 0 ? 12 : hours % 12) : hours.toString().padStart(2, '0');
  
  // Bengali period of day
  const getBengaliPeriod = (h: number): string => {
    if (h >= 4 && h < 12) return 'সকাল';
    if (h >= 12 && h < 15) return 'দুপুর';
    if (h >= 15 && h < 18) return 'বিকাল';
    if (h >= 18 && h < 20) return 'সন্ধ্যা';
    return 'রাত';
  };
  const bengaliPeriod = is12h ? getBengaliPeriod(hours) : '';

  // Bengali Gregorian date formatted
  const bengaliDateStr = formatBengaliGregorianDate(currentTime);

  return (
    <header className="relative w-full border-b border-amber-500/20 bg-gradient-to-b from-slate-900/95 to-slate-950/95 backdrop-blur-md px-4 sm:px-6 py-3.5 transition-all font-bengali">
      {/* Subtle Islamic arch / geometric accent hairline */}
      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />

      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-4">
        {/* Left Zone: Mosque Name and Location in Bengali */}
        <div className="flex flex-col items-center lg:items-start text-center lg:text-left">
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5">
            <h1 className="text-2xl lg:text-3xl font-black tracking-tight text-amber-100 font-bengali drop-shadow-sm">
              {settings.mosqueName}
            </h1>
            <span className="text-xl lg:text-2xl font-bold text-amber-400 font-arabic">
              {settings.mosqueArabicName}
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 mt-1 text-xs text-amber-200/80 font-medium font-bengali">
            <span className="text-slate-300">{settings.hallName}</span>
            <span aria-hidden="true">·</span>
            <span>{settings.location.city}, {settings.location.country}</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-300 font-semibold">{settings.juristic === 'Hanafi' ? 'হানাফী' : 'শাফেয়ী'} মাযহাব</span>
            {(hijriDate.isSpecialDayBengali || hijriDate.isSpecialDay) && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  {hijriDate.isSpecialDayBengali || hijriDate.isSpecialDay}
                </span>
              </>
            )}
          </div>

          {/* Mosque Leadership Badges: Imam & President */}
          {settings.showLeadership && (settings.imamName || settings.presidentName) && (
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 mt-2 text-xs font-bengali">
              {settings.imamName && (
                <div
                  onClick={onOpenTimeEditor}
                  title="ইমাম সাহেবের নাম পরিবর্তন করতে ক্লিক করুন"
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 cursor-pointer hover:border-amber-400 transition-all group shadow-sm hover:bg-emerald-900/60"
                >
                  <span className="text-emerald-400 font-bold text-[11px]">খতিব ও ইমাম:</span>
                  <span className="font-bold text-amber-200">{settings.imamName}</span>
                  <Edit3 className="w-3 h-3 text-slate-400 group-hover:text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity ml-0.5" />
                </div>
              )}
              {settings.presidentName && (
                <div
                  onClick={onOpenTimeEditor}
                  title="মসজিদ সভাপতির নাম পরিবর্তন করতে ক্লিক করুন"
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 border border-amber-500/40 text-amber-200 cursor-pointer hover:border-amber-300 transition-all group shadow-sm hover:bg-slate-800"
                >
                  <span className="text-amber-400 font-bold text-[11px]">সভাপতি:</span>
                  <span className="font-bold text-slate-100">{settings.presidentName}</span>
                  <Edit3 className="w-3 h-3 text-slate-400 group-hover:text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity ml-0.5" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Center Zone: Live Real-Time Digital Clock */}
        <div className="flex items-center gap-3 px-5 sm:px-6 py-2 rounded-2xl bg-slate-900/90 border border-amber-500/30 shadow-inner shadow-black/50">
          <div className="flex items-baseline font-mono tabular-nums tracking-wider text-amber-300 font-bold">
            <span className="text-4xl lg:text-5xl drop-shadow-[0_0_12px_rgba(251,191,36,0.35)]">
              {displayHours}:{minutes}
            </span>
            {settings.showSeconds && (
              <span className="text-2xl lg:text-3xl text-amber-400/70 ml-1">
                :{seconds}
              </span>
            )}
            {is12h && (
              <span className="text-xs sm:text-sm font-bengali font-bold text-amber-400 bg-amber-500/15 px-2 py-0.5 rounded-md ml-2.5 tracking-normal border border-amber-500/25">
                {bengaliPeriod}
              </span>
            )}
          </div>
        </div>

        {/* Right Zone: Dual Calendars & Display Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          {/* Dual Islamic Hijri & Bengali Gregorian Dates */}
          <div className="text-center sm:text-right font-bengali">
            <div className="text-sm font-bold text-amber-300 tracking-wide">
              {hijriDate.formattedBengali}
            </div>
            <div className="text-xs text-amber-200/80 font-arabic mt-0.5">
              {hijriDate.formattedArabic}
            </div>
            <div className="text-[11px] text-slate-300 mt-0.5 font-medium">
              {bengaliDateStr}
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 shadow-md">
            {/* Audio Toggle */}
            <button
              onClick={onToggleMute}
              title={settings.soundMuted ? 'বিপ অডিও সাউন্ড চালু করুন' : 'বিপ অডিও সাউন্ড নিঃশব্দ করুন'}
              className={`p-2 rounded-lg transition-colors cursor-pointer ${
                settings.soundMuted
                  ? 'text-red-400 hover:bg-red-950/40'
                  : 'text-amber-400 hover:bg-amber-400/10'
              }`}
            >
              {settings.soundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            {/* Test Sound Button */}
            <button
              onClick={onTestSound}
              title="বিপ সাউন্ড পরীক্ষা করতে ক্লিক করুন"
              className="px-2.5 py-1.5 text-xs font-semibold text-amber-200 hover:text-white hover:bg-amber-500/20 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>বিপ টেস্ট</span>
            </button>

            {/* Quick Time Editor Button */}
            <button
              onClick={onOpenTimeEditor}
              title="নামাজ ও জুমার সময়সূচি পরিবর্তন করুন"
              className="px-2.5 py-1.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-all flex items-center gap-1.5 shadow-sm cursor-pointer hover:scale-105"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>সময় পরিবর্তন</span>
            </button>

            {/* Seasonal Explorer */}
            <button
              onClick={onOpenSeasonalExplorer}
              title="ঋতুভিত্তিক সৌর হিসাব ও মাইলফলক দেখুন"
              className="p-2 text-slate-300 hover:text-amber-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Compass className="w-4 h-4" />
            </button>

            {/* Fullscreen TV Mode */}
            <button
              onClick={onToggleFullscreen}
              title={isFullscreen ? 'ফুলস্ক্রিন বন্ধ করুন' : 'টিভি ডিসপ্লে পূর্ণ পর্দায় প্রদর্শন করুন'}
              className="p-2 text-slate-300 hover:text-amber-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Settings */}
            <button
              onClick={onOpenSettings}
              title="মসজিদের মূল সেটিংস ও কনফিগারেশন"
              className="p-2 text-slate-300 hover:text-amber-300 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
