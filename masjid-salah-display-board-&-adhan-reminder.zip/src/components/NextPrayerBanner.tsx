import React from 'react';
import { DailyPrayerTimes, MosqueSettings } from '../types/prayer';
import { formatRemainingTime } from '../utils/astronomicalPrayerCalc';
import { Bell, Clock, Users, ShieldAlert, Star } from 'lucide-react';

interface NextPrayerBannerProps {
  prayerData: DailyPrayerTimes;
  settings: MosqueSettings;
  onTestSound: () => void;
}

export const NextPrayerBanner: React.FC<NextPrayerBannerProps> = ({
  prayerData,
  settings,
}) => {
  const { nextEvent, prayers, isInSalahWindow, activeSalahKey, date } = prayerData;
  const isFriday = date.getDay() === 5;
  const isJumuaUpcoming = isFriday && nextEvent.prayerKey === 'dhuhr';

  const targetPrayer = prayers[nextEvent.prayerKey];
  const { formatted } = formatRemainingTime(nextEvent.remainingMs);

  const reminderMinutes = settings.reminders[nextEvent.prayerKey]?.minutesBeforeAdhan ?? 1;
  const isReminderEnabled = settings.reminders[nextEvent.prayerKey]?.enabled ?? true;

  // Active Salah state takes highest visual precedence
  if (isInSalahWindow && activeSalahKey) {
    const currentPrayerObj = prayers[activeSalahKey];
    const isJumuaNow = isFriday && activeSalahKey === 'dhuhr';
    return (
      <div className="w-full max-w-7xl mx-auto my-3 px-4 font-bengali">
        <div className="relative overflow-hidden rounded-2xl border-2 border-red-500/60 bg-gradient-to-r from-red-950/90 via-slate-900/95 to-red-950/90 p-5 sm:p-6 shadow-2xl backdrop-blur-md text-center animate-pulse">
          <div className="flex flex-col items-center justify-center gap-2">
            <div className="flex items-center gap-2 text-red-300 font-bold tracking-wide text-sm sm:text-base">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <span>
                {isJumuaNow ? 'পবিত্র জুমার জামাত চলছে' : `${currentPrayerObj.bengaliName}র জামাত চলছে`} · অনুগ্রহ করে মোবাইল ফোন বন্ধ বা সাইলেন্ট রাখুন
              </span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold text-red-100 font-arabic">
              {isJumuaNow
                ? 'صلاة الجمعة قائمة الآن — الرجاء إغلاق الهواتف'
                : `صلاة ${currentPrayerObj.arabicName} قائمة الآن — الرجاء إغلاق الهواتف`}
            </h2>
            <p className="text-xs sm:text-sm text-slate-200 max-w-xl mx-auto mt-1">
              সম্পূর্ণ নীরবতা বজায় রাখুন, মোবাইলের রিংটোন বন্ধ রাখুন এবং কাতার সোজা করে ফাঁকা জায়গা পূরণ করুন।
            </p>
          </div>
        </div>
      </div>
    );
  }

  const isIqamah = nextEvent.type === 'iqamah';

  return (
    <div className="w-full max-w-7xl mx-auto my-3 px-4 font-bengali">
      <div
        className={`relative overflow-hidden rounded-2xl border ${
          isJumuaUpcoming
            ? 'border-2 border-amber-400 bg-gradient-to-r from-amber-950/70 via-slate-900 to-emerald-950/70 shadow-2xl shadow-amber-500/20'
            : 'border-amber-500/30 bg-gradient-to-r from-slate-900/95 via-slate-800/85 to-slate-900/95 shadow-2xl shadow-black/60'
        } p-4 sm:p-5 lg:p-6 backdrop-blur-md`}
      >
        {/* Subtle accent glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/15 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-5 sm:gap-6">
          {/* Left: Upcoming Prayer Details */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider mb-1">
              {isJumuaUpcoming ? (
                <div className="flex items-center gap-1.5 text-amber-300 font-bold bg-amber-400/20 px-2.5 py-0.5 rounded-full border border-amber-400/40">
                  <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                  <span>আসন্ন পবিত্র জুমু'আ</span>
                </div>
              ) : isIqamah ? (
                <>
                  <Users className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-300 font-bold">আসন্ন জামাত (ইক্বামত)</span>
                </>
              ) : (
                <>
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span className="text-amber-300 font-bold">পরবর্তী ওয়াক্ত (আযান)</span>
                </>
              )}
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="font-arabic text-amber-300 text-base">
                {isJumuaUpcoming ? 'صلاة الجمعة' : targetPrayer.arabicName}
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-amber-100 tracking-tight font-bengali">
                {isJumuaUpcoming ? 'পবিত্র জুমু\'আ' : targetPrayer.bengaliName}
              </h2>
              <span className="text-2xl sm:text-3xl font-bold text-amber-400 font-arabic">
                {isJumuaUpcoming ? 'الجمعة' : targetPrayer.arabicName}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 mt-2.5 text-xs text-slate-300">
              {isJumuaUpcoming ? (
                <>
                  <div className="flex items-center gap-1.5 bg-slate-950/80 px-3 py-1.5 rounded-lg border border-amber-500/50">
                    <span className="text-amber-300 font-semibold">১ম আযান:</span>
                    <span className="font-mono font-bold text-amber-300 tabular-nums text-sm">
                      {settings.jumuaAdhanTime}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-slate-950/80 px-3 py-1.5 rounded-lg border border-emerald-500/50">
                    <span className="text-emerald-300 font-semibold">খুতবা:</span>
                    <span className="font-mono font-bold text-emerald-300 tabular-nums text-sm">
                      {settings.jumuaKhutbahTime}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-emerald-950/90 px-3 py-1.5 rounded-lg border-2 border-emerald-400">
                    <span className="text-emerald-200 font-bold">জুমার জামাত:</span>
                    <span className="font-mono font-black text-white tabular-nums text-sm">
                      {settings.jumuaTime}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-slate-700/60">
                    <span className="text-slate-400">আযান:</span>
                    <span className="font-mono font-bold text-amber-300 tabular-nums text-sm">
                      {targetPrayer.adhanTimeFormatted}
                    </span>
                  </div>

                  {targetPrayer.iqamahTimeFormatted !== '--' && (
                    <div className="flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-emerald-700/40">
                      <span className="text-emerald-400 font-medium">জামাত:</span>
                      <span className="font-mono font-bold text-emerald-300 tabular-nums text-sm">
                        {targetPrayer.iqamahTimeFormatted}
                      </span>
                    </div>
                  )}
                </>
              )}

              {/* Pre-Adhan Reminder Indicator */}
              {!isIqamah && isReminderEnabled && (
                <div className="flex items-center gap-1.5 bg-amber-500/15 px-3 py-1.5 rounded-lg border border-amber-500/40 text-amber-300">
                  <Bell className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                  <span>{reminderMinutes} মিনিট পূর্বে বিপ অ্যালার্ট বাজবে</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Giant Digital Countdown Display */}
          <div className="flex flex-col items-center md:items-end">
            <div className="text-xs font-semibold text-amber-200/90 tracking-wide mb-1">
              {isJumuaUpcoming
                ? 'জুমার প্রথম আযানের বাকি'
                : isIqamah
                ? 'জামাত শুরু হতে সময় বাকি'
                : 'ওয়াক্ত শুরু (আযান) হতে বাকি'}
            </div>

            <div className="bg-slate-950/95 border-2 border-amber-500/50 rounded-2xl px-6 py-2.5 sm:px-8 sm:py-3 shadow-inner shadow-black/90 flex items-center justify-center">
              <div className="font-mono tabular-nums text-4xl sm:text-5xl lg:text-6xl font-black tracking-wider text-amber-300 drop-shadow-[0_0_15px_rgba(251,191,36,0.45)]">
                {formatted}
              </div>
            </div>

            {/* Sub-label under countdown in pure Bengali */}
            <div className="flex items-center gap-2 mt-2 text-xs text-slate-300">
              {isJumuaUpcoming ? (
                <span className="text-amber-200 font-medium">পবিত্র জুমার সালাতের প্রস্তুতি গ্রহণ করুন</span>
              ) : isIqamah ? (
                <span className="text-emerald-300">সুন্নত নামাজ সম্পন্ন করে কাতারে শামিল হোন</span>
              ) : (
                <span>
                  {reminderMinutes > 0 && isReminderEnabled
                    ? `আযানের ঠিক ${reminderMinutes} মিনিট পূর্বে স্বয়ংক্রিয় বিপ সংকেত বাজবে`
                    : 'ওয়াক্ত হওয়ার সাথে সাথে আযান অনুষ্ঠিত হবে'}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
