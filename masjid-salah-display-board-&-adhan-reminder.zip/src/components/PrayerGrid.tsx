import React from 'react';
import { DailyPrayerTimes, MosqueSettings, PrayerKey } from '../types/prayer';
import {
  Sun,
  Sunrise,
  Sunset,
  Moon,
  CloudSun,
  Sparkles,
  Bell,
  Clock,
  Edit3,
  Star,
  CheckCircle2,
} from 'lucide-react';

interface PrayerGridProps {
  prayerData: DailyPrayerTimes;
  settings: MosqueSettings;
  onEditPrayer?: (key: PrayerKey) => void;
  onEditJumua?: () => void;
}

export const PrayerGrid: React.FC<PrayerGridProps> = ({
  prayerData,
  settings,
  onEditPrayer,
  onEditJumua,
}) => {
  const { prayerList, extras } = prayerData;
  const isFriday = prayerData.date.getDay() === 5;

  const prayerIcons: Record<PrayerKey, React.ReactNode> = {
    fajr: <Sunrise className="w-6 h-6 text-sky-400" />,
    sunrise: <Sun className="w-6 h-6 text-amber-400" />,
    dhuhr: <Sun className="w-6 h-6 text-amber-300" />,
    asr: <CloudSun className="w-6 h-6 text-orange-400" />,
    maghrib: <Sunset className="w-6 h-6 text-rose-400" />,
    isha: <Moon className="w-6 h-6 text-indigo-400" />,
  };

  const prayerSubtitles: Record<PrayerKey, string> = {
    fajr: 'ভোর (সুবহে সাদিক)',
    sunrise: 'ইশরাক ওয়াক্ত শুরু',
    dhuhr: isFriday ? 'পবিত্র জুমু\'আ' : 'দুপুর (মধ্যাহ্ন)',
    asr: 'বিকাল (ওয়াক্ত)',
    maghrib: 'সন্ধ্যা (সূর্যাস্ত)',
    isha: 'রাত্রি (ওয়াক্ত)',
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 pb-4 font-bengali">
      {/* HIGHLIGHTED JUMMAH (পবিত্র জুমু'আ) SHOWCASE BANNER - MAJESTIC GOLD & EMERALD */}
      <div className="mb-4 relative overflow-hidden rounded-2xl border-2 border-amber-400/90 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 p-4 sm:p-5 shadow-2xl shadow-emerald-500/25 ring-2 ring-amber-400/40">
        {/* Decorative Islamic corner glows */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-amber-400/20 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
        <div className="absolute bottom-0 left-0 w-72 h-72 bg-emerald-500/25 rounded-full blur-3xl pointer-events-none -ml-16 -mb-16" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-4">
          {/* Left: Jummah Title & Hadith in Bengali */}
          <div className="flex items-center gap-3.5 text-center lg:text-left">
            <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-400/60 shadow-inner flex items-center justify-center">
              <Star className="w-7 h-7 text-amber-400 fill-amber-400 animate-pulse" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2 justify-center lg:justify-start">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-950 bg-amber-400 px-2.5 py-0.5 rounded-full font-bengali shadow-sm">
                  ★ বিশেষ জুমু'আ ওয়াক্ত ★
                </span>
                <span className="text-lg sm:text-2xl font-bold text-amber-200">
                  পবিত্র জুমু'আ মোবারক
                </span>
                <span className="text-lg sm:text-2xl font-bold text-amber-400 font-arabic">
                  صلاة الجمعة المباركة
                </span>
                {isFriday && (
                  <span className="text-xs font-bold text-emerald-300 bg-emerald-900/80 border border-emerald-400/50 px-2 py-0.5 rounded-full">
                    আজ পবিত্র জুমাবার
                  </span>
                )}
              </div>
              <div className="text-xs text-emerald-200/90 mt-1 max-w-xl">
                রাসূলুল্লাহ ﷺ বলেছেন: <span className="font-semibold text-amber-200">"দিনসমূহের মধ্যে সর্বোত্তম ও সম্মানিত দিন হলো জুমার দিন।"</span> (আবু দাউদ) · মসজিদে আগে ভাগে উপস্থিত হয়ে খুতবা মনোযোগ সহকারে শ্রবণ করুন।
              </div>
            </div>
          </div>

          {/* Right: Jummah 3 Times Badges + Edit Button */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3">
            {/* 1st Adhan */}
            <div className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-slate-950/95 border-2 border-amber-400/60 text-center shadow-lg">
              <span className="text-[11px] text-amber-300 font-semibold block">
                ১ম আযান
              </span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.45)]">
                {settings.jumuaAdhanTime}
              </span>
              <span className="text-[9px] text-amber-200/70 block mt-0.5">প্রথম সতর্কবার্তা</span>
            </div>

            {/* Khutbah / 2nd Adhan */}
            <div className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-slate-950/95 border-2 border-emerald-500/60 text-center shadow-lg">
              <span className="text-[11px] text-emerald-300 font-semibold block">
                খুতবা ও ২য় আযান
              </span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-emerald-300 drop-shadow-[0_0_10px_rgba(52,211,153,0.45)]">
                {settings.jumuaKhutbahTime}
              </span>
              <span className="text-[9px] text-emerald-200/70 block mt-0.5">খুতবা বয়ান</span>
            </div>

            {/* Jumma Salah (Jamat) - Highlighted Most Prominently */}
            <div className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-gradient-to-b from-emerald-900 to-emerald-950 border-2 border-amber-300 text-center shadow-2xl ring-2 ring-emerald-400/50">
              <span className="text-[11px] text-amber-200 font-extrabold block">
                জুমার মূল জামাত
              </span>
              <span className="text-xl sm:text-2xl font-black font-mono tabular-nums text-white drop-shadow-[0_0_12px_rgba(255,255,255,0.6)]">
                {settings.jumuaTime}
              </span>
              <span className="text-[9px] text-emerald-200 block mt-0.5 font-bold">ফরজ সালাত</span>
            </div>

            {/* Quick Edit Jummah Button */}
            <button
              onClick={onEditJumua}
              className="px-3.5 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all flex items-center gap-1.5 shadow-md shrink-0 cursor-pointer hover:scale-105"
              title="জুমার সময়সূচি পরিবর্তন করতে ক্লিক করুন"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>জুমার সময় পরিবর্তন</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6-Card Main Daily Prayer Schedule */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {prayerList.map((prayer) => {
          const isNext = prayer.isNext;
          const isCurrent = prayer.isCurrent;
          const reminderSetting = settings.reminders[prayer.key];
          const hasReminder = reminderSetting?.enabled && prayer.key !== 'sunrise';
          const isSunrise = prayer.key === 'sunrise';
          const isDhuhrOnFriday = isFriday && prayer.key === 'dhuhr';

          return (
            <div
              key={prayer.key}
              onClick={() => onEditPrayer?.(prayer.key)}
              role="button"
              tabIndex={0}
              title={`${prayer.bengaliName}র সময় পরিবর্তন করতে ক্লিক করুন`}
              className={`relative group cursor-pointer overflow-hidden rounded-2xl flex flex-col justify-between transition-all duration-300 border ${
                isDhuhrOnFriday
                  ? 'border-2 border-amber-400 bg-gradient-to-b from-amber-950/70 via-slate-900 to-slate-950 shadow-2xl shadow-amber-500/25 ring-2 ring-amber-400/60 transform -translate-y-1'
                  : isNext
                  ? 'border-amber-400 bg-gradient-to-b from-amber-950/40 via-slate-900/90 to-slate-950 shadow-lg shadow-amber-500/20 ring-2 ring-amber-400/40 transform -translate-y-0.5'
                  : isCurrent
                  ? 'border-emerald-500/60 bg-gradient-to-b from-emerald-950/30 via-slate-900/80 to-slate-950 shadow-md shadow-emerald-500/10'
                  : 'border-slate-800 bg-slate-900/60 hover:border-amber-500/50 hover:bg-slate-900/80'
              } p-4 sm:p-5`}
            >
              {/* Highlight ribbon for Next, Current, Friday or Custom */}
              {isDhuhrOnFriday ? (
                <div className="absolute top-0 right-0 bg-amber-400 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-bl-md uppercase tracking-wider font-bengali">
                  পবিত্র জুমাবার
                </div>
              ) : isNext ? (
                <div className="absolute top-0 right-0 bg-amber-500 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-bl-md uppercase tracking-wider font-bengali">
                  পরবর্তী ওয়াক্ত
                </div>
              ) : isCurrent ? (
                <div className="absolute top-0 right-0 bg-emerald-500/90 text-slate-950 text-[10px] font-bold px-2 py-0.5 rounded-bl-md uppercase tracking-wider font-bengali">
                  চলমান ওয়াক্ত
                </div>
              ) : prayer.isCustomOverride ? (
                <div className="absolute top-0 right-0 bg-amber-500/20 text-amber-300 text-[9px] font-semibold px-1.5 py-0.5 rounded-bl-md border-b border-l border-amber-500/30 font-bengali">
                  কাস্টম সময়
                </div>
              ) : null}

              {/* Hover Edit Tooltip Button */}
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md bg-amber-500 text-slate-950 shadow-md">
                <Edit3 className="w-3.5 h-3.5" />
              </div>

              {/* Card Header: Icon + Bengali & Arabic Names */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80 group-hover:border-amber-500/40 transition-colors">
                    {prayerIcons[prayer.key]}
                  </div>
                  <span className="text-xl sm:text-2xl font-bold font-arabic text-amber-300">
                    {prayer.arabicName}
                  </span>
                </div>

                <div className="flex items-baseline justify-between">
                  <h3 className="text-base sm:text-lg font-bold text-slate-100 tracking-tight font-bengali">
                    {isDhuhrOnFriday ? 'জুমু\'আ (যোহর)' : prayer.bengaliName}
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">
                    {prayerSubtitles[prayer.key]}
                  </span>
                </div>

                {isDhuhrOnFriday ? (
                  <div className="mt-1 text-[11px] font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/50">
                    আজ জুমার নামাজ অনুষ্ঠিত হবে
                  </div>
                ) : prayer.key === 'dhuhr' ? (
                  <div className="mt-1 text-[10px] text-emerald-300/80 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/40">
                    জুমাবার: আযান {settings.jumuaAdhanTime} · জামাত {settings.jumuaTime}
                  </div>
                ) : null}
              </div>

              {/* Center: Adhan Time */}
              <div className="my-4 py-3 px-2 rounded-xl bg-slate-950/80 border border-slate-800/80 text-center group-hover:border-amber-500/30 transition-colors">
                <span className="text-[11px] font-medium text-slate-400 tracking-wider block mb-0.5">
                  {isSunrise
                    ? 'সূর্যোদয় (ওয়াক্ত সমাপ্তি)'
                    : isDhuhrOnFriday
                    ? 'জুমার ১ম আযান'
                    : 'আযান (ওয়াক্ত শুরু)'}
                </span>
                <span className="text-2xl sm:text-3xl font-black font-mono tabular-nums text-amber-300 tracking-tight drop-shadow-[0_0_8px_rgba(251,191,36,0.25)]">
                  {isDhuhrOnFriday ? settings.jumuaAdhanTime : prayer.adhanTimeFormatted}
                </span>
              </div>

              {/* Bottom: Iqamah Time & Reminder status */}
              <div className="space-y-2">
                {!isSunrise && (
                  <div className="flex items-center justify-between text-xs px-2.5 py-2 rounded-lg bg-emerald-950/40 border border-emerald-800/40">
                    <span className="text-emerald-300 font-medium flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{isDhuhrOnFriday ? 'জুমার জামাত:' : 'জামাত:'}</span>
                    </span>
                    <span className="font-mono font-bold text-emerald-200 tabular-nums text-sm">
                      {isDhuhrOnFriday ? settings.jumuaTime : prayer.iqamahTimeFormatted}
                    </span>
                  </div>
                )}

                {/* Reminder Bip Status Indicator */}
                {hasReminder && (
                  <div className="flex items-center justify-between text-[11px] text-amber-300/90 px-2 py-1 rounded bg-amber-500/10 border border-amber-500/20">
                    <span className="flex items-center gap-1">
                      <Bell className="w-3 h-3 text-amber-400" />
                      <span>বিপ সংকেত:</span>
                    </span>
                    <span className="font-semibold text-amber-200 font-mono">
                      -{reminderSetting.minutesBeforeAdhan} মিনিট
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Extra Islamic Times: Suhoor/Imsak, Ishraq, Duha, Midnight, Tahajjud */}
      {settings.showExtraTimes && (
        <div className="mt-4 p-4 rounded-2xl bg-slate-900/70 border border-slate-800 text-xs text-slate-300">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-amber-300/90 tracking-wide text-xs flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>নফল ও অতিরিক্ত ওয়াক্তসমূহ (الأوقات الإضافية)</span>
            </span>
            <span className="text-[11px] text-slate-400">সৌর হিসাব অনুযায়ী নির্ধারিত</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 text-center font-mono">
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-[11px] text-slate-400 block font-sans font-medium">সেহরি শেষ (ইমসাক)</span>
              <span className="text-amber-200 font-bold tabular-nums text-sm">
                {extras.imsak.formatted}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-[11px] text-slate-400 block font-sans font-medium">ইশরাক (সূর্যোদয় পরবর্তী)</span>
              <span className="text-amber-200 font-bold tabular-nums text-sm">
                {extras.ishraq.formatted}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-[11px] text-slate-400 block font-sans font-medium">চাশত / সালাত উদ-দোহা</span>
              <span className="text-amber-200 font-bold tabular-nums text-sm">
                {extras.duha.formatted}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-[11px] text-slate-400 block font-sans font-medium">ইসলামিক মধ্যরাত</span>
              <span className="text-amber-200 font-bold tabular-nums text-sm">
                {extras.midnight.formatted}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800 col-span-2 sm:col-span-1">
              <span className="text-[11px] text-slate-400 block font-sans font-medium">তাহাজ্জুদ (রাতের শেষ তৃতীয়াংশ)</span>
              <span className="text-amber-200 font-bold tabular-nums text-sm">
                {extras.tahajjud.formatted}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
