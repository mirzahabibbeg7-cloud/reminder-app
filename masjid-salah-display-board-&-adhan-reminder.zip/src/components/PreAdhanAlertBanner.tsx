import React from 'react';
import { ActiveReminderAlert } from '../hooks/usePrayerTimes';
import { Bell, Volume2, X } from 'lucide-react';

interface PreAdhanAlertBannerProps {
  alert: ActiveReminderAlert;
  onDismiss: () => void;
}

export const PreAdhanAlertBanner: React.FC<PreAdhanAlertBannerProps> = ({
  alert,
  onDismiss,
}) => {
  return (
    <div className="fixed top-20 inset-x-4 z-50 max-w-2xl mx-auto animate-bounce font-bengali">
      <div className="relative overflow-hidden rounded-2xl border-2 border-amber-400 bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 p-4 shadow-2xl shadow-amber-500/30 backdrop-blur-xl flex items-center justify-between gap-4">
        {/* Glowing aura */}
        <div className="absolute inset-0 bg-amber-500/10 pointer-events-none" />

        <div className="relative flex items-center gap-3.5">
          <div className="p-3 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 animate-pulse">
            <Bell className="w-6 h-6 text-amber-400" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                {alert.type === 'adhan' ? 'আযানের পূর্ব সতর্কতা' : 'জামাতের পূর্ব সতর্কতা'}
              </span>
              <span aria-hidden="true" className="text-amber-500">·</span>
              <span className="text-xs text-amber-200/80 font-mono">বিপ সাউন্ড সক্রিয়</span>
            </div>
            <div className="text-lg font-bold text-amber-100 mt-0.5">
              {alert.type === 'adhan'
                ? `${alert.minutesLeft} মিনিট পর আযান অনুষ্ঠিত হবে`
                : `${alert.minutesLeft} মিনিট পর জামাত শুরু হবে`}
            </div>
            <div className="text-xs text-amber-300 font-arabic mt-0.5">
              حي على الصلاة — حي على الفلاح
            </div>
          </div>
        </div>

        <button
          onClick={onDismiss}
          className="relative p-2 text-amber-300 hover:text-white hover:bg-amber-500/20 rounded-lg transition-colors"
          title="বিজ্ঞপ্তি বন্ধ করুন"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
