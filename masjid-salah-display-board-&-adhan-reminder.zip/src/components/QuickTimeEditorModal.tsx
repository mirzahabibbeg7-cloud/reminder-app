import React, { useState } from 'react';
import { MosqueSettings, PrayerKey, PrayerTimeOverride } from '../types/prayer';
import {
  X,
  Clock,
  Check,
  RotateCcw,
  Sliders,
  Star,
  UserCheck,
} from 'lucide-react';

interface QuickTimeEditorModalProps {
  settings: MosqueSettings;
  onSave: (updated: MosqueSettings) => void;
  onClose: () => void;
  initialSelectedPrayer?: PrayerKey;
}

export const QuickTimeEditorModal: React.FC<QuickTimeEditorModalProps> = ({
  settings,
  onSave,
  onClose,
  initialSelectedPrayer,
}) => {
  const [formData, setFormData] = useState<MosqueSettings>(() =>
    JSON.parse(JSON.stringify(settings))
  );
  const [saveSuccess, setSaveSuccess] = useState(false);

  const prayersList: { key: PrayerKey; name: string; arabic: string }[] = [
    { key: 'fajr', name: 'ফজর (ভোর)', arabic: 'الفجر' },
    { key: 'sunrise', name: 'সূর্যোদয় (ইশরাক)', arabic: 'الشروق' },
    { key: 'dhuhr', name: 'যোহর (দুপুর)', arabic: 'الظهر' },
    { key: 'asr', name: 'আসর (বিকাল)', arabic: 'العصر' },
    { key: 'maghrib', name: 'মাগরিব (সন্ধ্যা)', arabic: 'المغرب' },
    { key: 'isha', name: 'এশা (রাত)', arabic: 'العشاء' },
  ];

  const handleToggleOverride = (key: PrayerKey, enabled: boolean) => {
    setFormData((prev) => {
      const current = prev.timeOverrides?.[key] || {
        enabled: false,
        adhanTime: '12:00',
        iqamahTime: '12:15',
      };
      return {
        ...prev,
        timeOverrides: {
          ...prev.timeOverrides,
          [key]: {
            ...current,
            enabled,
          },
        },
      };
    });
  };

  const handleUpdateTime = (
    key: PrayerKey,
    field: 'adhanTime' | 'iqamahTime',
    val: string
  ) => {
    setFormData((prev) => {
      const current = prev.timeOverrides?.[key] || {
        enabled: true,
        adhanTime: '12:00',
        iqamahTime: '12:15',
      };
      return {
        ...prev,
        timeOverrides: {
          ...prev.timeOverrides,
          [key]: {
            ...current,
            enabled: true, // auto-enable override when user edits time
            [field]: val,
          },
        },
      };
    });
  };

  const handleResetAllToAuto = () => {
    setFormData((prev) => {
      const cleared: Record<PrayerKey, PrayerTimeOverride> = {
        fajr: { enabled: false, adhanTime: '05:15', iqamahTime: '05:45' },
        sunrise: { enabled: false, adhanTime: '06:15' },
        dhuhr: { enabled: false, adhanTime: '12:45', iqamahTime: '13:15' },
        asr: { enabled: false, adhanTime: '16:30', iqamahTime: '17:00' },
        maghrib: { enabled: false, adhanTime: '18:15', iqamahTime: '18:25' },
        isha: { enabled: false, adhanTime: '19:45', iqamahTime: '20:15' },
      };
      return { ...prev, timeOverrides: cleared };
    });
  };

  const handleSave = () => {
    onSave(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto font-bengali">
      <div className="relative w-full max-w-4xl rounded-2xl border border-amber-500/40 bg-slate-900 shadow-2xl my-6 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-amber-100">
                  নামাজ ও জুমার সময়সূচি এডিটর
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold">
                  {formData.mosqueName}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                আযান, জামাত ও পবিত্র জুমার নির্দিষ্ট সময় সেট করুন, অথবা স্বয়ংক্রিয় ঋতুভিত্তিক সোলার হিসাব ব্যবহার করুন।
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action ribbon in pure Bengali */}
        <div className="px-6 py-2.5 bg-slate-950/60 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="text-slate-300">
            যেকোনো সময় বক্সে ক্লিক করে সরাসরি সময় পরিবর্তন করতে পারেন। <strong className="text-amber-300">কাস্টম সময়</strong> অথবা <strong className="text-sky-300">অটো সোলার ক্যালকুলেশন</strong> নির্বাচন করুন।
          </span>
          <button
            onClick={handleResetAllToAuto}
            className="px-2.5 py-1 text-slate-300 hover:text-amber-300 hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1.5 cursor-pointer border border-slate-700/50"
            title="সব ওয়াক্তের সময়কে স্বয়ংক্রিয় সোলার ক্যালকুলেশনে রিসেট করুন"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>সব অটো-হিসাবে রিসেট করুন</span>
          </button>
        </div>

        {/* Prayer Time Edit Rows */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-200">
          {/* FRIDAY JUMMA SECTION (HIGHLIGHTED PROMINENTLY) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-2 border-amber-400 shadow-xl ring-1 ring-amber-400/40">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                <span className="text-sm sm:text-base font-bold text-amber-200">
                  পবিত্র জুমু'আর সময়সূচি (صلاة الجمعة المباركة)
                </span>
              </div>
              <span className="text-xs text-slate-950 bg-amber-400 px-2.5 py-0.5 rounded-full font-bold shadow-sm">
                ★ জুমু'আ স্পেশাল ★
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Jumma 1st Adhan */}
              <div className="p-3 rounded-xl bg-slate-950/90 border border-amber-500/50">
                <label className="text-amber-300 font-semibold block mb-1">
                  জুমার ১ম আযান
                </label>
                <input
                  type="time"
                  value={formData.jumuaAdhanTime}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      jumuaAdhanTime: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-amber-500/40 text-amber-300 font-mono text-base font-bold focus:border-amber-400 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  জুমার প্রথম সতর্কবার্তা আযানের সময়
                </span>
              </div>

              {/* Jumma Khutbah */}
              <div className="p-3 rounded-xl bg-slate-950/90 border border-emerald-500/50">
                <label className="text-emerald-300 font-semibold block mb-1">
                  খুতবা ও ২য় আযান
                </label>
                <input
                  type="time"
                  value={formData.jumuaKhutbahTime}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      jumuaKhutbahTime: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-500/40 text-emerald-300 font-mono text-base font-bold focus:border-emerald-400 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  খুতবা বয়ান ও মিম্বরের আযান
                </span>
              </div>

              {/* Jumma Salah / Jamat */}
              <div className="p-3 rounded-xl bg-gradient-to-b from-emerald-950 to-slate-950 border-2 border-amber-300 shadow-md">
                <label className="text-amber-200 font-bold block mb-1">
                  জুমার মূল জামাত
                </label>
                <input
                  type="time"
                  value={formData.jumuaTime}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      jumuaTime: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-400 text-white font-mono text-base font-bold focus:border-emerald-300 focus:outline-none"
                />
                <span className="text-[10px] text-emerald-300 mt-1 block font-medium">
                  জুমার ফরজ নামাজের জামাতের সময়
                </span>
              </div>
            </div>
          </div>

          {/* MOSQUE LEADERSHIP: EDITABLE IMAM NAME & MASJID PRESIDENT NAME */}
          <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-sm font-bold text-slate-100">
                  মসজিদ পরিচালনা ও সম্মানিত খতিব / ইমাম (Imam & President)
                </span>
              </div>
              <label className="flex items-center gap-1.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={formData.showLeadership}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      showLeadership: e.target.checked,
                    }))
                  }
                  className="rounded accent-emerald-400 w-3.5 h-3.5"
                />
                <span className="text-slate-300">বোর্ডে প্রদর্শন করুন</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Imam Name */}
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/40">
                <label className="text-emerald-300 font-bold block mb-1">
                  সম্মানিত ইমাম সাহেবের নাম (Imam Name)
                </label>
                <input
                  type="text"
                  value={formData.imamName || ''}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      imamName: e.target.value,
                    }))
                  }
                  placeholder="যেমন: হাফেজ মাওলানা মোঃ ক্বারী সাহেব..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-emerald-500/30 text-amber-200 font-bold text-sm focus:border-amber-400 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  খতিব ও পেশ ইমাম সাহেবের নাম
                </span>
              </div>

              {/* President Name */}
              <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/40">
                <label className="text-amber-300 font-bold block mb-1">
                  মসজিদ সভাপতির নাম (Masjid President Name)
                </label>
                <input
                  type="text"
                  value={formData.presidentName || ''}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      presidentName: e.target.value,
                    }))
                  }
                  placeholder="যেমন: জনাব মোঃ সভাপতি সাহেব..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-amber-500/30 text-slate-100 font-bold text-sm focus:border-amber-400 focus:outline-none"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  মসজিদ পরিচালনা কমিটির সভাপতি / মুতাওয়াল্লীর নাম
                </span>
              </div>
            </div>
          </div>

          {/* DAILY 5 PRAYERS + SUNRISE EDITING */}
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5" />
              <span>দৈনিক পাঁচ ওয়াক্ত নামাজ ও সূর্যোদয় (আযান ও জামাতের সময়)</span>
            </div>

            <div className="divide-y divide-slate-800 rounded-xl bg-slate-950/60 border border-slate-800">
              {prayersList.map(({ key, name, arabic }) => {
                const override = formData.timeOverrides?.[key] || {
                  enabled: false,
                  adhanTime: '12:00',
                  iqamahTime: '12:15',
                };
                const isSunrise = key === 'sunrise';
                const isFocused = initialSelectedPrayer === key;

                return (
                  <div
                    key={key}
                    className={`p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-colors ${
                      isFocused ? 'bg-amber-500/15 ring-1 ring-amber-400/40' : ''
                    }`}
                  >
                    {/* Left: Prayer Name & Toggle Mode */}
                    <div className="min-w-[190px]">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-100 text-sm">
                          {name}
                        </span>
                        <span className="font-arabic text-amber-400 text-base">
                          {arabic}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mt-1.5">
                        <label className="flex items-center gap-1.5 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={override.enabled}
                            onChange={(e) => handleToggleOverride(key, e.target.checked)}
                            className="rounded accent-amber-400 w-3.5 h-3.5"
                          />
                          <span
                            className={`text-[11px] font-medium ${
                              override.enabled ? 'text-amber-300 font-semibold' : 'text-slate-400'
                            }`}
                          >
                            {override.enabled ? 'কাস্টম নির্দিষ্ট সময়' : 'অটো সোলার হিসাব'}
                          </span>
                        </label>
                      </div>
                    </div>

                    {/* Right: Adhan & Iqamah Time Inputs */}
                    <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                      {/* Adhan Time */}
                      <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-700/80">
                        <span className="text-slate-400 text-xs">
                          {isSunrise ? 'সূর্যোদয়:' : 'আযান:'}
                        </span>
                        <input
                          type="time"
                          value={override.adhanTime || '12:00'}
                          onChange={(e) => handleUpdateTime(key, 'adhanTime', e.target.value)}
                          className={`bg-transparent font-mono text-sm font-bold focus:outline-none ${
                            override.enabled ? 'text-amber-300' : 'text-slate-400 opacity-70'
                          }`}
                        />
                      </div>

                      {/* Iqamah Time */}
                      {!isSunrise && (
                        <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-700/80">
                          <span className="text-emerald-400 text-xs">জামাত:</span>
                          <input
                            type="time"
                            value={override.iqamahTime || '12:15'}
                            onChange={(e) =>
                              handleUpdateTime(key, 'iqamahTime', e.target.value)
                            }
                            className={`bg-transparent font-mono text-sm font-bold focus:outline-none ${
                              override.enabled ? 'text-emerald-300' : 'text-slate-400 opacity-70'
                            }`}
                          />
                        </div>
                      )}

                      {/* Mode status indicator */}
                      <span className="text-[11px]">
                        {override.enabled ? (
                          <span className="text-amber-400 font-semibold">● কাস্টম কার্যকর</span>
                        ) : (
                          <span className="text-sky-400">● অটো আপডেট হচ্ছে</span>
                        )}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 shrink-0 bg-slate-950/60">
          <div className="text-xs text-slate-300">
            {saveSuccess ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <Check className="w-4 h-4" />
                <span>সময়সূচি সফলভাবে সংরক্ষিত হয়েছে!</span>
              </span>
            ) : (
              <span>পরিবর্তনগুলো সাথে সাথে মূল লাইভ ডিসপ্লে বোর্ডে প্রদর্শিত হবে</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md hover:scale-105"
            >
              <Check className="w-4 h-4" />
              <span>সংরক্ষণ ও বোর্ডে প্রয়োগ</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
