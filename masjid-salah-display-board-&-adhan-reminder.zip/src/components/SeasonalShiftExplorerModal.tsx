import React, { useState } from 'react';
import { MosqueSettings } from '../types/prayer';
import {
  calculateDailyPrayerTimes,
  calculateSeasonalShifts,
} from '../utils/astronomicalPrayerCalc';
import { X, Calendar, Compass, Sparkles } from 'lucide-react';

interface SeasonalShiftExplorerModalProps {
  settings: MosqueSettings;
  onClose: () => void;
}

export const SeasonalShiftExplorerModal: React.FC<SeasonalShiftExplorerModalProps> = ({
  settings,
  onClose,
}) => {
  const currentYear = new Date().getFullYear();
  const seasonalPoints = calculateSeasonalShifts(currentYear, settings);

  // Custom preview date
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().slice(0, 10)
  );

  const previewDateObj = new Date(selectedDate + 'T12:00:00');
  const previewTimes = calculateDailyPrayerTimes(previewDateObj, settings);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto font-bengali">
      <div className="relative w-full max-w-4xl rounded-2xl border border-amber-500/30 bg-slate-900 p-6 shadow-2xl my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-amber-100">
                ঋতুভিত্তিক পরিবর্তন ও সোলার সময়সূচি
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                সৌর অবস্থানের পরিবর্তন এবং সূর্যের উচ্চতা কোণের ভিত্তিতে {settings.location.city}-এর জন্য ৩৬৫ দিন স্বয়ংক্রিয়ভাবে নামাজের সময় নির্ধারিত হয়।
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Season Solstice/Equinox Breakdown */}
        <div className="mt-5">
          <div className="text-xs font-semibold tracking-wider text-amber-400 mb-3 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>চার ঋতুর প্রধান সৌর মাইলফলকসমূহ ({currentYear})</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {seasonalPoints.map((pt) => {
              const bnSeasonName =
                pt.seasonName === 'Spring Equinox'
                  ? 'বসন্ত বিষুব'
                  : pt.seasonName === 'Summer Solstice'
                  ? 'গ্রীষ্মের দীর্ঘতম দিন'
                  : pt.seasonName === 'Autumn Equinox'
                  ? 'শরৎ বিষুব'
                  : 'শীতের ক্ষুদ্রতম দিন';

              return (
                <div
                  key={pt.seasonName}
                  className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-amber-300/80 mb-1">
                      <span className="font-semibold">{pt.dateStr}</span>
                      <span className="font-arabic">{pt.seasonArabic}</span>
                    </div>
                    <div className="font-bold text-slate-100 text-sm">{bnSeasonName}</div>
                    <div className="text-[11px] text-emerald-400 font-medium mt-1">
                      দিনের দৈর্ঘ্য: {pt.dayLengthHours} ঘণ্টা
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs font-mono space-y-1">
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">ফজর:</span>
                      <span className="text-amber-200 font-mono">{pt.fajr}</span>
                    </div>
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">সূর্যোদয়:</span>
                      <span className="text-amber-200 font-mono">{pt.sunrise}</span>
                    </div>
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">যোহর:</span>
                      <span className="text-amber-200 font-mono">{pt.dhuhr}</span>
                    </div>
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">আসর:</span>
                      <span className="text-amber-200 font-mono">{pt.asr}</span>
                    </div>
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">মাগরিব:</span>
                      <span className="text-amber-200 font-mono">{pt.maghrib}</span>
                    </div>
                    <div className="flex justify-between font-sans">
                      <span className="text-slate-400">এশা:</span>
                      <span className="text-amber-200 font-mono">{pt.isha}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Interactive Date Scrubber */}
        <div className="mt-6 p-4 rounded-xl bg-slate-950/50 border border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
            <div>
              <div className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                <span>বছরের যেকোনো দিনের নামাজের সময় প্রিভিউ করুন</span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                তারিখ নির্বাচন করে দেখুন সৌর অবস্থানের পরিবর্তনের সাথে সাথে সময় কীভাবে পরিবর্তিত হয়
              </div>
            </div>

            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 text-xs font-mono focus:border-amber-400 focus:outline-none"
            />
          </div>

          {/* Calculated Output Table */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center font-mono">
            {previewTimes.prayerList.map((p) => (
              <div
                key={p.key}
                className="p-3 rounded-lg bg-slate-900 border border-slate-800"
              >
                <div className="text-[11px] font-sans text-slate-300 font-bold mb-1">
                  {p.bengaliName}
                </div>
                <div className="text-sm font-bold text-amber-300 tabular-nums">
                  {p.adhanTimeFormatted}
                </div>
                {p.iqamahTimeFormatted !== '--' && (
                  <div className="text-[10px] text-emerald-400 mt-1 font-sans">
                    জামাত: <span className="font-mono">{p.iqamahTimeFormatted}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
