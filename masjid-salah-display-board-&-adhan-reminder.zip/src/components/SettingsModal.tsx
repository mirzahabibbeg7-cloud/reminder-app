import React, { useState } from 'react';
import {
  MosqueSettings,
  PrayerKey,
  SoundType,
  CalculationMethodId,
  JuristicMethod,
  HighLatitudeRule,
} from '../types/prayer';
import {
  POPULAR_CITIES,
} from '../utils/astronomicalPrayerCalc';
import {
  X,
  Bell,
  MapPin,
  Clock,
  Palette,
  Sparkles,
  Sliders,
  Check,
  Navigation,
  Star,
} from 'lucide-react';

interface SettingsModalProps {
  settings: MosqueSettings;
  onSave: (updated: MosqueSettings) => void;
  onClose: () => void;
  onTestSound: (soundType: SoundType) => void;
}

type TabKey = 'reminders' | 'location' | 'iqamah' | 'display';

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onSave,
  onClose,
  onTestSound,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('reminders');
  const [formData, setFormData] = useState<MosqueSettings>(() =>
    JSON.parse(JSON.stringify(settings))
  );
  const [geoLoading, setGeoLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Bengali Calculation Method Names
  const CALC_METHODS_BN: Record<CalculationMethodId, { name: string; desc: string }> = {
    Karachi: {
      name: 'করাচি ইসলামিক বিজ্ঞান বিশ্ববিদ্যালয় (বাংলাদেশ/ভারত/পাকিস্তান)',
      desc: 'ফজর ১৮°, এশা ১৮° · উপমহাদেশে সর্বাধিক নির্ভরযোগ্য',
    },
    Makkah: {
      name: 'উম্মুল কুরা বিশ্ববিদ্যালয়, মক্কা মুকাররমা',
      desc: 'ফজর ১৮.৫°, এশা ৯০ মিনিট পর',
    },
    MWL: {
      name: 'মুসলিম ওয়ার্ল্ড লীগ (মক্কা রাবেতা)',
      desc: 'ফজর ১৮°, এশা ১৭°',
    },
    ISNA: {
      name: 'ইসলামিক সোসাইটি অব নর্থ আমেরিকা (ISNA)',
      desc: 'ফজর ১৫°, এশা ১৫°',
    },
    Egypt: {
      name: 'মিশরীয় জেনারেল সার্ভে কর্তৃপক্ষ',
      desc: 'ফজর ১৯.৫°, এশা ১৭.৫°',
    },
    Gulf: {
      name: 'উপসাগরীয় অঞ্চল ও দুবাই ইসলামিক এফেয়ার্স',
      desc: 'ফজর ১৮.২°, এশা ৯০ মিনিট পর',
    },
    Turkey: {
      name: 'তুরস্ক দিয়ানত বিষয়ক মন্ত্রণালয়',
      desc: 'ফজর ১৮°, এশা ১৭°',
    },
    Singapore: {
      name: 'সিঙ্গাপুর মজলিস উগামা ইসলাম (MUIS)',
      desc: 'ফজর ২০°, এশা ১৮°',
    },
    Tehran: {
      name: 'তেহরান জিওফিজিক্স ইনস্টিটিউট',
      desc: 'ফজর ১৭.৭°, এশা ১৪°',
    },
    France: {
      name: 'ফ্রান্সের ইসলামিক সংগঠন (UOIF ১২°)',
      desc: 'ফজর ১২°, এশা ১২°',
    },
    Custom: {
      name: 'কাস্টম কোণ ও প্যারামিটার',
      desc: 'ব্যবহারকারী নির্ধারিত কোণ',
    },
  };

  // Popular Cities with Bengali Names
  const BENGALI_CITIES: { city: string; label: string }[] = [
    { city: 'Bandarbani (PIN 721504)', label: 'বান্দারবানি (পিন-৭২১৫০৪)' },
    { city: 'Jhargram', label: 'ঝাড়গ্রাম' },
    { city: 'Midnapore', label: 'মেদিনীপুর' },
    { city: 'Kolkata', label: 'কলকাতা' },
    { city: 'Dhaka', label: 'ঢাকা' },
    { city: 'Makkah', label: 'মক্কা' },
    { city: 'Madinah', label: 'মদিনা' },
    { city: 'Jerusalem', label: 'জেরুজালেম' },
    { city: 'Cairo', label: 'কায়রো' },
    { city: 'Istanbul', label: 'ইস্তাম্বুল' },
    { city: 'Dubai', label: 'দুবাই' },
    { city: 'London', label: 'লন্ডন' },
  ];

  const handleCitySelect = (cityName: string) => {
    if (cityName === 'Bandarbani (PIN 721504)' || cityName === 'Bandarbani') {
      setFormData((prev) => ({
        ...prev,
        location: {
          city: 'বান্দারবানি (পিন-৭২১৫০৪)',
          country: 'ঝাড়গ্রাম, পশ্চিমবঙ্গ, ভারত',
          latitude: 22.5057,
          longitude: 86.9922,
          timezone: 5.5,
          autoDetectTimezone: true,
          elevation: 85,
        },
      }));
      return;
    }
    if (cityName === 'Jhargram') {
      setFormData((prev) => ({
        ...prev,
        location: {
          city: 'ঝাড়গ্রাম',
          country: 'পশ্চিমবঙ্গ, ভারত',
          latitude: 22.4500,
          longitude: 86.9833,
          timezone: 5.5,
          autoDetectTimezone: true,
          elevation: 81,
        },
      }));
      return;
    }
    if (cityName === 'Midnapore') {
      setFormData((prev) => ({
        ...prev,
        location: {
          city: 'মেদিনীপুর',
          country: 'পশ্চিমবঙ্গ, ভারত',
          latitude: 22.4257,
          longitude: 87.3199,
          timezone: 5.5,
          autoDetectTimezone: true,
          elevation: 23,
        },
      }));
      return;
    }
    if (cityName === 'Kolkata') {
      setFormData((prev) => ({
        ...prev,
        location: {
          city: 'কলকাতা',
          country: 'পশ্চিমবঙ্গ, ভারত',
          latitude: 22.5726,
          longitude: 88.3639,
          timezone: 5.5,
          autoDetectTimezone: true,
          elevation: 9,
        },
      }));
      return;
    }

    const found = POPULAR_CITIES.find((c) => c.city === cityName);
    if (found) {
      const bnMatch = BENGALI_CITIES.find((b) => b.city === cityName);
      setFormData((prev) => ({
        ...prev,
        location: {
          ...prev.location,
          city: bnMatch ? bnMatch.label : found.city,
          country: found.country,
          latitude: found.latitude,
          longitude: found.longitude,
          timezone: found.timezone,
          elevation: found.elevation,
        },
      }));
    }
  };

  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('আপনার ব্রাউজারে স্বয়ংক্রিয় লোকেশন জিপিএস সমর্থিত নয়।');
      return;
    }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = parseFloat(pos.coords.latitude.toFixed(4));
        const lon = parseFloat(pos.coords.longitude.toFixed(4));
        const tz = -new Date().getTimezoneOffset() / 60;
        setFormData((prev) => ({
          ...prev,
          location: {
            ...prev.location,
            city: 'স্থানীয় মসজিদ',
            country: 'বাংলাদেশ',
            latitude: lat,
            longitude: lon,
            timezone: tz,
            autoDetectTimezone: true,
            elevation: 10,
          },
        }));
        setGeoLoading(false);
      },
      (err) => {
        setGeoLoading(false);
        alert('বর্তমান অবস্থান নির্ণয় করা যায়নি: ' + err.message);
      },
      { timeout: 10000 }
    );
  };

  const handleSave = () => {
    onSave(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 400);
  };

  const prayersList: { key: PrayerKey; name: string }[] = [
    { key: 'fajr', name: 'ফজর' },
    { key: 'dhuhr', name: 'যোহর' },
    { key: 'asr', name: 'আসর' },
    { key: 'maghrib', name: 'মাগরিব' },
    { key: 'isha', name: 'এশা' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto font-bengali">
      <div className="relative w-full max-w-4xl rounded-2xl border border-amber-500/30 bg-slate-900 shadow-2xl my-8 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-amber-100">
                মসজিদ ডিসপ্লে ও সালাত সেটিংস
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                আযানের পূর্ববর্তী বিপ অ্যালার্ট, জামাত ও জুমার সময়সূচি এবং সোলার হিসাব কাস্টমাইজ করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-800 px-6 bg-slate-950/40 gap-1 overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('reminders')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'reminders'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bell className="w-4 h-4 text-amber-400" />
            <span>রিমাইন্ডার বিপ অডিও</span>
          </button>

          <button
            onClick={() => setActiveTab('location')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'location'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MapPin className="w-4 h-4 text-sky-400" />
            <span>লোকেশন ও সোলার হিসাব</span>
          </button>

          <button
            onClick={() => setActiveTab('iqamah')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'iqamah'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>জামাত ও জুমার সময়</span>
          </button>

          <button
            onClick={() => setActiveTab('display')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'display'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-4 h-4 text-purple-400" />
            <span>মসজিদ ও ডিসপ্লে</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs text-slate-300">
          {/* TAB 1: REMINDER BEEP CUSTOMIZATION */}
          {activeTab === 'reminders' && (
            <div className="space-y-6">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-amber-200">
                    আযানের পূর্ববর্তী সতর্কবার্তা বিপ সিস্টেম
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    আযান হওয়ার পূর্বে স্বয়ংক্রিয়ভাবে অডিও বিপ বাজবে (ডিফল্ট: ১ মিনিট পূর্বে, তবে প্রতিটি নামাজের জন্য পৃথক মিনিট নির্ধারণ করতে পারেন)।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onTestSound(formData.reminders.dhuhr.soundType || 'beep_classic')
                  }
                  className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all flex items-center gap-1.5 shrink-0 cursor-pointer shadow-md hover:scale-105"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>বিপ টেস্ট</span>
                </button>
              </div>

              {/* Master Volume & Sound Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                  <label className="font-semibold text-slate-200 block mb-2">
                    রিমাইন্ডার বিপ সাউন্ড স্টাইল
                  </label>
                  <select
                    value={formData.reminders.dhuhr.soundType}
                    onChange={(e) => {
                      const sound = e.target.value as SoundType;
                      setFormData((prev) => {
                        const updated = { ...prev.reminders };
                        Object.keys(updated).forEach((k) => {
                          updated[k as PrayerKey] = {
                            ...updated[k as PrayerKey],
                            soundType: sound,
                          };
                        });
                        return { ...prev, reminders: updated };
                      });
                      onTestSound(sound);
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 focus:border-amber-400 focus:outline-none"
                  >
                    <option value="beep_classic">ক্লাসিক মসজিদ ডিজিটাল ক্লক (৩ পিপ + ১ দীর্ঘ বিপ)</option>
                    <option value="beep_soft_chime">কোমল মধুর সুর (৫২৮ হার্টজ বেল চিম)</option>
                    <option value="beep_double_pip">ডুয়েল ডিজিটাল পিপ (উচ্চ স্পষ্টতা)</option>
                    <option value="beep_pulsed">পালস অ্যালার্ট (৩ দ্রুত পালস)</option>
                  </select>
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    ওয়েব অডিও এপিআই দ্বারা সিন্থেসাইজ করা হয়।
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                  <label className="font-semibold text-slate-200 block mb-2 flex justify-between">
                    <span>মাস্টার অডিও ভলিউম</span>
                    <span className="text-amber-400 font-mono">
                      {Math.round(formData.globalVolume * 100)}%
                    </span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={formData.globalVolume}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        globalVolume: parseFloat(e.target.value),
                      }))
                    }
                    className="w-full accent-amber-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>শান্ত (০%)</span>
                    <span>স্বাভাবিক (৫০%)</span>
                    <span>সর্বোচ্চ (১০০%)</span>
                  </div>
                </div>
              </div>

              {/* Per-Prayer Reminder Minutes Before Adhan */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div className="text-sm font-bold text-amber-300 mb-3">
                  নামাজভিত্তিক আযানের পূর্বে বিপ বাজার সময় (মিনিট)
                </div>

                <div className="divide-y divide-slate-800">
                  {prayersList.map(({ key, name }) => {
                    const reminder = formData.reminders[key] || {
                      enabled: true,
                      minutesBeforeAdhan: 1,
                      soundType: 'beep_classic',
                    };

                    return (
                      <div
                        key={key}
                        className="py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={reminder.enabled}
                            onChange={(e) => {
                              const enabled = e.target.checked;
                              setFormData((prev) => ({
                                ...prev,
                                reminders: {
                                  ...prev.reminders,
                                  [key]: { ...reminder, enabled },
                                },
                              }));
                            }}
                            className="rounded accent-amber-400 w-4 h-4 cursor-pointer"
                            id={`reminder-enable-${key}`}
                          />
                          <label
                            htmlFor={`reminder-enable-${key}`}
                            className="font-medium text-slate-100 cursor-pointer text-sm"
                          >
                            {name}
                          </label>
                        </div>

                        <div className="flex items-center gap-3 self-end sm:self-auto">
                          <span className="text-slate-400 text-xs">
                            বিপ অ্যালার্ট:
                          </span>
                          <div className="flex items-center gap-1.5">
                            {[1, 2, 5, 10, 15].map((min) => (
                              <button
                                key={min}
                                type="button"
                                onClick={() => {
                                  setFormData((prev) => ({
                                    ...prev,
                                    reminders: {
                                      ...prev.reminders,
                                      [key]: {
                                        ...reminder,
                                        minutesBeforeAdhan: min,
                                      },
                                    },
                                  }));
                                }}
                                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                                  reminder.minutesBeforeAdhan === min
                                    ? 'bg-amber-500 text-slate-950 font-bold'
                                    : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
                                }`}
                              >
                                -{min}মি.
                              </button>
                            ))}

                            <div className="flex items-center ml-2">
                              <input
                                type="number"
                                min="1"
                                max="60"
                                value={reminder.minutesBeforeAdhan}
                                onChange={(e) => {
                                  const val = Math.max(
                                    1,
                                    Math.min(60, parseInt(e.target.value) || 1)
                                  );
                                  setFormData((prev) => ({
                                    ...prev,
                                    reminders: {
                                      ...prev.reminders,
                                      [key]: {
                                        ...reminder,
                                        minutesBeforeAdhan: val,
                                      },
                                    },
                                  }));
                                }}
                                className="w-14 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-amber-200 text-center font-mono focus:outline-none"
                              />
                              <span className="ml-1 text-slate-400">মিনিট</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pre-Iqamah Beep Alert */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">
                    জামাতের পূর্ববর্তী সতর্কবার্তা বিপ
                  </div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    ইক্বামতের পূর্বে মুসল্লীদের কাতার সোজা করতে একটি মৃদু বিপ ধ্বনি বাজবে।
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={formData.enablePreIqamahBeep}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        enablePreIqamahBeep: e.target.checked,
                      }))
                    }
                    className="rounded accent-emerald-400 w-4 h-4 cursor-pointer"
                  />
                  <select
                    value={formData.preIqamahMinutes}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        preIqamahMinutes: parseInt(e.target.value) || 2,
                      }))
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-emerald-300 font-mono"
                  >
                    <option value="1">জামাতের ১ মিনিট পূর্বে</option>
                    <option value="2">জামাতের ২ মিনিট পূর্বে</option>
                    <option value="3">জামাতের ৩ মিনিট পূর্বে</option>
                    <option value="5">জামাতের ৫ মিনিট পূর্বে</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LOCATION & SEASONAL SHIFTS */}
          {activeTab === 'location' && (
            <div className="space-y-6">
              {/* Presets and GPS */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-3">
                  <div className="font-semibold text-slate-200 text-sm">
                    মসজিদের অবস্থান ও শহর নির্বাচন করুন
                  </div>
                  <button
                    type="button"
                    onClick={handleDetectLocation}
                    disabled={geoLoading}
                    className="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer shadow-sm"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>{geoLoading ? 'জিপিএস শনাক্ত হচ্ছে...' : 'আমার অবস্থান নির্ণয় করুন'}</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 mb-3">
                  {BENGALI_CITIES.map((c) => (
                    <button
                      key={c.city}
                      type="button"
                      onClick={() => handleCitySelect(c.city)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                        formData.location.city === c.label || formData.location.city === c.city
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                          : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>

                {/* Quick PIN Code 721504 Button */}
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>
                      বর্তমান অবস্থান পিন কোড: <strong className="text-amber-300 font-mono">PIN-721504</strong> (বান্দারবানি, ঝাড়গ্রাম)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCitySelect('Bandarbani (PIN 721504)')}
                    className="px-3 py-1 rounded bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs cursor-pointer shadow-sm shrink-0"
                  >
                    পিন-৭২১৫০৪ প্রয়োগ করুন
                  </button>
                </div>
              </div>

              {/* Coordinates & Timezone Inputs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="text-slate-400 block mb-1">শহর / অঞ্চল</label>
                  <input
                    type="text"
                    value={formData.location.city}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        location: { ...prev.location, city: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">অক্ষাংশ (°N)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={formData.location.latitude}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        location: {
                          ...prev.location,
                          latitude: parseFloat(e.target.value) || 0,
                        },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">দ্রাঘিমাংশ (°E)</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={formData.location.longitude}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        location: {
                          ...prev.location,
                          longitude: parseFloat(e.target.value) || 0,
                        },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">টাইমজোন (UTC)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={formData.location.timezone}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        location: {
                          ...prev.location,
                          timezone: parseFloat(e.target.value) || 0,
                        },
                      }))
                    }
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 font-mono"
                  />
                </div>
              </div>

              {/* Calculation Convention & Juristic School */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="font-semibold text-slate-200 block mb-1.5">
                    নামাজের ক্যালকুলেশন মেথড
                  </label>
                  <select
                    value={formData.method}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        method: e.target.value as CalculationMethodId,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 text-xs"
                  >
                    {Object.entries(CALC_METHODS_BN).map(([id, meta]) => (
                      <option key={id} value={id}>
                        {meta.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-200 block mb-1.5">
                    আসরের মাযহাবী নিয়ম
                  </label>
                  <select
                    value={formData.juristic}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        juristic: e.target.value as JuristicMethod,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 text-xs"
                  >
                    <option value="Hanafi">হানাফী মাযহাব (বস্তুর ছায়া ২ গুণ)</option>
                    <option value="Standard">শাফেয়ী / মালেকী / হাম্বলী (বস্তুর ছায়া ১ গুণ)</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-200 block mb-1.5">
                    উচ্চ অক্ষাংশ সমন্বয় নিয়ম
                  </label>
                  <select
                    value={formData.highLatitudeRule}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        highLatitudeRule: e.target.value as HighLatitudeRule,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 text-xs"
                  >
                    <option value="AngleBased">অ্যাঙ্গেল বেসড নিয়ম</option>
                    <option value="OneSeventh">রাতের ৭ ভাগের ১ ভাগ</option>
                    <option value="NightMiddle">রাতের মধ্যভাগ (১/২)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: IQAMAH & CONGREGATION */}
          {activeTab === 'iqamah' && (
            <div className="space-y-6">
              {/* HIGHLIGHTED JUMMAH SETTINGS SECTION */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-2 border-amber-400 shadow-xl ring-1 ring-amber-400/40">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                  <span className="font-bold text-amber-200 text-base">
                    পবিত্র জুমু'আর সময়সূচি (صلاة الجمعة المباركة)
                  </span>
                  <span className="text-xs bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-bold ml-auto">
                    জুমু'আ বিশেষ
                  </span>
                </div>
                <p className="text-xs text-emerald-200/80 mb-3">
                  জুমাবার উপলক্ষে ১ম আযান, খুতবা ও মূল জামাতের নির্দিষ্ট সময় নির্ধারণ করুন।
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-amber-500/50">
                    <label className="text-amber-300 font-semibold block mb-1">জুমার ১ম আযান</label>
                    <input
                      type="time"
                      value={formData.jumuaAdhanTime || '12:30'}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          jumuaAdhanTime: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-amber-500/50 text-amber-300 font-mono text-base font-bold focus:border-amber-400 focus:outline-none"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">প্রথম আযানের সময়</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-500/50">
                    <label className="text-emerald-300 font-semibold block mb-1">খুতবা ও ২য় আযান</label>
                    <input
                      type="time"
                      value={formData.jumuaKhutbahTime}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          jumuaKhutbahTime: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-500/50 text-emerald-300 font-mono text-base font-bold focus:border-emerald-400 focus:outline-none"
                    />
                    <span className="text-[10px] text-slate-400 mt-1 block">খুতবা শুরু ও ২য় আযান</span>
                  </div>
                  <div className="p-3 rounded-xl bg-gradient-to-b from-emerald-950 to-slate-950 border-2 border-amber-300 shadow-md">
                    <label className="text-amber-200 font-bold block mb-1">জুমার মূল জামাত</label>
                    <input
                      type="time"
                      value={formData.jumuaTime}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          jumuaTime: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-400 text-white font-mono text-base font-bold focus:border-emerald-300 focus:outline-none"
                    />
                    <span className="text-[10px] text-emerald-300 mt-1 block font-medium">জুমার ফরজ জামাত</span>
                  </div>
                </div>
              </div>

              {/* Canonical Iqamah Times */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div className="text-sm font-bold text-emerald-300 mb-2">
                  দৈনিক পাঁচ ওয়াক্ত নামাজের জামাতের সময়
                </div>
                <div className="divide-y divide-slate-800">
                  {prayersList.map(({ key, name }) => {
                    const iq = formData.iqamahSettings[key] || {
                      type: 'offset',
                      offsetMinutes: 15,
                      fixedTime: '13:15',
                      roundToNearest5: true,
                    };

                    return (
                      <div
                        key={key}
                        className="py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div className="font-bold text-slate-100">{name}</div>

                        <div className="flex items-center gap-3">
                          <select
                            value={iq.type}
                            onChange={(e) => {
                              const type = e.target.value as 'offset' | 'fixed';
                              setFormData((prev) => ({
                                ...prev,
                                iqamahSettings: {
                                  ...prev.iqamahSettings,
                                  [key]: { ...iq, type },
                                },
                              }));
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 text-xs"
                          >
                            <option value="offset">আযানের পর নির্দিষ্ট মিনিট</option>
                            <option value="fixed">নির্দিষ্ট ঘড়ির সময়</option>
                          </select>

                          {iq.type === 'offset' ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-slate-400">+</span>
                              <input
                                type="number"
                                min="0"
                                max="60"
                                value={iq.offsetMinutes}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value) || 0;
                                  setFormData((prev) => ({
                                    ...prev,
                                    iqamahSettings: {
                                      ...prev.iqamahSettings,
                                      [key]: { ...iq, offsetMinutes: val },
                                    },
                                  }));
                                }}
                                className="w-14 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-emerald-300 font-mono text-center"
                              />
                              <span className="text-slate-400">মিনিট</span>
                            </div>
                          ) : (
                            <input
                              type="time"
                              value={iq.fixedTime}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormData((prev) => ({
                                  ...prev,
                                  iqamahSettings: {
                                    ...prev.iqamahSettings,
                                    [key]: { ...iq, fixedTime: val },
                                  },
                                }));
                              }}
                              className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-emerald-300 font-mono font-bold"
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DISPLAY & MOSQUE DETAILS */}
          {activeTab === 'display' && (
            <div className="space-y-6">
              {/* Mosque Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="text-slate-400 block mb-1">মসজিদের নাম (বাংলা)</label>
                  <input
                    type="text"
                    value={formData.mosqueName}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        mosqueName: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200 text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">মসজিদের নাম (আরবি)</label>
                  <input
                    type="text"
                    value={formData.mosqueArabicName}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        mosqueArabicName: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-400 font-arabic text-sm text-right"
                  />
                </div>
              </div>

              {/* Imam Name & President Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="text-emerald-300 font-bold block mb-1">সম্মানিত ইমাম সাহেবের নাম (Imam Name)</label>
                  <input
                    type="text"
                    value={formData.imamName || ''}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        imamName: e.target.value,
                      }))
                    }
                    placeholder="যেমন: হাফেজ মাওলানা মোঃ ক্বারী সাহেব..."
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-emerald-500/30 text-amber-200 text-sm font-bold focus:border-amber-400 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">খতিব ও পেশ ইমাম সাহেবের নাম</span>
                </div>
                <div>
                  <label className="text-amber-300 font-bold block mb-1">মসজিদ সভাপতির নাম (Masjid President Name)</label>
                  <input
                    type="text"
                    value={formData.presidentName || ''}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        presidentName: e.target.value,
                      }))
                    }
                    placeholder="যেমন: জনাব মোঃ সভাপতি সাহেব..."
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-amber-500/30 text-slate-100 text-sm font-bold focus:border-amber-400 focus:outline-none"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">মসজিদ পরিচালনা কমিটির সভাপতি / মুতাওয়াল্লীর নাম</span>
                </div>
                <div className="sm:col-span-2 pt-1 flex items-center justify-between border-t border-slate-800/80">
                  <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-200 font-medium">
                    <input
                      type="checkbox"
                      checked={formData.showLeadership}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          showLeadership: e.target.checked,
                        }))
                      }
                      className="rounded accent-emerald-400 w-4 h-4 cursor-pointer"
                    />
                    <span>ডিসপ্লে বোর্ডের হেডারে ইমাম ও সভাপতির নাম প্রদর্শন করুন</span>
                  </label>
                </div>
              </div>

              {/* Time format & Seconds & Hijri Offset */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <div>
                  <label className="text-slate-400 block mb-1">ঘড়ির প্রদর্শন ফরম্যাট</label>
                  <select
                    value={formData.timeFormat}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        timeFormat: e.target.value as '12h' | '24h',
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200"
                  >
                    <option value="12h">১২-ঘণ্টা (সকাল/দুপুর/বিকাল/রাত)</option>
                    <option value="24h">২৪-ঘণ্টা মিলিটারি ফরম্যাট</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">হিজরি তারিখ সমন্বয় (চাঁদ দেখা)</label>
                  <select
                    value={formData.hijriOffsetDays}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        hijriOffsetDays: parseInt(e.target.value) || 0,
                      }))
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-amber-200"
                  >
                    <option value="-2">-২ দিন</option>
                    <option value="-1">-১ দিন</option>
                    <option value="0">স্ট্যান্ডার্ড হিসাব</option>
                    <option value="1">+১ দিন</option>
                    <option value="2">+২ দিন</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 cursor-pointer pb-2">
                    <input
                      type="checkbox"
                      checked={formData.showSeconds}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          showSeconds: e.target.checked,
                        }))
                      }
                      className="rounded accent-amber-400 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-slate-200 font-medium">লাইভ সেকেন্ড ঘড়ি প্রদর্শন</span>
                  </label>
                </div>
              </div>

              {/* Ticker Announcements */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <label className="font-semibold text-slate-200 block mb-2">
                  মসজিদ নোটিশ / হাদিস বার্তা
                </label>
                <textarea
                  rows={4}
                  value={formData.announcements.join('\n')}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      announcements: e.target.value.split('\n').filter((l) => l.trim()),
                    }))
                  }
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 leading-relaxed font-sans text-xs focus:outline-none"
                  placeholder="প্রতি লাইনে একটি করে নোটিশ বা হাদিস লিখুন..."
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  প্রতিটি বার্তা প্রতি ১০ সেকেন্ড পরপর ডিসপ্লের নিচের ব্যানারে স্ক্রল করবে।
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 shrink-0 bg-slate-950/60">
          <div className="text-xs text-slate-300">
            {saveSuccess ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <Check className="w-4 h-4" />
                <span>সেটিংস সফলভাবে সংরক্ষিত হয়েছে!</span>
              </span>
            ) : (
              <span>সকল তথ্য ব্রাউজার মেমোরিতে সুরক্ষিতভাবে সংরক্ষিত থাকে</span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              বাতিল
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md hover:scale-105"
            >
              <Check className="w-4 h-4" />
              <span>সংরক্ষণ করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
