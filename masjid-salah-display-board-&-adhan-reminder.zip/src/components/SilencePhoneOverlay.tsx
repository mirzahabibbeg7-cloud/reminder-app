import React from 'react';
import { DailyPrayerTimes } from '../types/prayer';
import { Smartphone, VolumeX, X, Sparkles } from 'lucide-react';

interface SilencePhoneOverlayProps {
  prayerData: DailyPrayerTimes;
  onDismiss: () => void;
}

export const SilencePhoneOverlay: React.FC<SilencePhoneOverlayProps> = ({
  prayerData,
  onDismiss,
}) => {
  if (!prayerData.isInSalahWindow || !prayerData.activeSalahKey) return null;

  const currentPrayer = prayerData.prayers[prayerData.activeSalahKey];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 backdrop-blur-xl p-6 transition-all duration-500 font-bengali">
      <div className="relative w-full max-w-3xl rounded-3xl border-2 border-emerald-500/40 bg-gradient-to-b from-slate-900 to-slate-950 p-8 sm:p-12 text-center shadow-2xl shadow-emerald-500/10">
        <button
          onClick={onDismiss}
          className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="নামাজ স্ক্রিন বন্ধ করুন"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Animated silent phone iconography */}
        <div className="mx-auto w-24 h-24 rounded-full bg-emerald-500/15 border-2 border-emerald-400/30 flex items-center justify-center mb-6 animate-pulse">
          <div className="relative">
            <Smartphone className="w-12 h-12 text-emerald-300" />
            <div className="absolute -bottom-1 -right-1 bg-red-500 text-white rounded-full p-1 border-2 border-slate-900">
              <VolumeX className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Arabic Calligraphy Header */}
        <h2 className="text-3xl sm:text-5xl font-bold font-arabic text-amber-300 mb-3 tracking-wide">
          الرجاء إغلاق الهواتف أو وضعها على الصامت
        </h2>

        <div className="text-2xl sm:text-3xl font-bold text-slate-100 mb-2">
          {currentPrayer.bengaliName}র জামাত চলছে
        </div>

        <p className="text-base sm:text-lg text-emerald-200 font-semibold mb-2">
          অনুগ্রহ করে মোবাইল ফোন বন্ধ অথবা সাইলেন্ট রাখুন
        </p>

        <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto leading-relaxed mb-6 italic">
          "তোমাদের কাতারসমূহ সোজা করো এবং কাঁধে কাঁধ মেলাও, নিশ্চয় কাতার সোজা করা নামাজের সৌন্দর্যের অংশ।"
        </p>

        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-xs text-emerald-300">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>জামাত সমাপ্ত হলে স্বয়ংক্রিয়ভাবে ডিসপ্লে বোর্ডে ফিরে যাবে</span>
        </div>
      </div>
    </div>
  );
};
