import React, { useState, useEffect } from 'react';
import { MosqueSettings } from '../types/prayer';
import { MessageSquareQuote } from 'lucide-react';

interface TickerBarProps {
  settings: MosqueSettings;
  currentTime: Date;
}

export const TickerBar: React.FC<TickerBarProps> = ({ settings }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const messages = settings.announcements && settings.announcements.length > 0
    ? settings.announcements
    : ['মসজিদে স্বাগতম · অনুগ্রহ করে শান্ত পরিবেশ বজায় রাখুন ও মোবাইল বন্ধ রাখুন।'];

  // Rotate messages every 10 seconds
  useEffect(() => {
    if (messages.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % messages.length);
    }, 10000);
    return () => clearInterval(interval);
  }, [messages.length]);

  return (
    <footer className="relative w-full border-t border-slate-800 bg-slate-950/90 backdrop-blur-md px-6 py-2.5 transition-all text-xs font-bengali">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Left: Announcement Tag and Rotating Text */}
        <div className="flex items-center gap-3 w-full sm:w-auto overflow-hidden">
          <div className="flex items-center gap-1.5 shrink-0 text-amber-400 font-semibold text-xs">
            <MessageSquareQuote className="w-3.5 h-3.5" />
            <span>মসজিদ নোটিশ:</span>
          </div>

          <div className="text-slate-200 font-medium truncate transition-opacity duration-300">
            {messages[currentIndex]}
          </div>
        </div>

        {/* Right: Astronomical & Location Metadata */}
        <div className="flex items-center gap-2 shrink-0 text-[11px] text-slate-400">
          <span>অক্ষাংশ: {settings.location.latitude.toFixed(2)}°</span>
          <span aria-hidden="true">·</span>
          <span>দ্রাঘিমাংশ: {settings.location.longitude.toFixed(2)}°</span>
          <span aria-hidden="true">·</span>
          <span className="text-amber-300 font-semibold">সৌর ঋতুভিত্তিক অটো-হিসাব সক্রিয়</span>
        </div>
      </div>
    </footer>
  );
};
