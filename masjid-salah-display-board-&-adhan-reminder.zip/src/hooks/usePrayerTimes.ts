import { useState, useEffect, useRef, useCallback } from 'react';
import { MosqueSettings, DailyPrayerTimes, PrayerKey } from '../types/prayer';
import { calculateDailyPrayerTimes } from '../utils/astronomicalPrayerCalc';
import { audioSynth } from '../utils/audioSynthesizer';

export interface ActiveReminderAlert {
  prayerKey: PrayerKey;
  prayerName: string;
  type: 'adhan' | 'iqamah';
  minutesLeft: number;
  message: string;
  timestamp: number;
}

export function usePrayerTimes(settings: MosqueSettings) {
  const [now, setNow] = useState<Date>(() => new Date());
  const [activeAlert, setActiveAlert] = useState<ActiveReminderAlert | null>(null);
  const [audioUnlocked, setAudioUnlocked] = useState<boolean>(() => audioSynth.getUnlockedStatus());

  // Keep track of triggered reminders so we only beep once per event
  const triggeredEventsRef = useRef<Set<string>>(new Set());

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Calculate prayer times for current moment
  const prayerData: DailyPrayerTimes = calculateDailyPrayerTimes(now, settings);

  // Monitor pre-adhan and pre-iqamah reminders
  useEffect(() => {
    const nowMs = now.getTime();
    const dateStr = now.toISOString().slice(0, 10); // YYYY-MM-DD

    // 1. Check Pre-Adhan Reminders
    for (const prayer of prayerData.prayerList) {
      const reminder = settings.reminders[prayer.key];
      if (!reminder || !reminder.enabled) continue;

      const adhanMs = prayer.timeDate.getTime();
      const diffMs = adhanMs - nowMs;
      const targetWindowMs = reminder.minutesBeforeAdhan * 60 * 1000;

      // Within 2 seconds of the reminder threshold (e.g., exactly at 1 min before adhan)
      if (diffMs > 0 && diffMs <= targetWindowMs && diffMs >= targetWindowMs - 2500) {
        const eventId = `adhan-${prayer.key}-${dateStr}-${reminder.minutesBeforeAdhan}m`;
        if (!triggeredEventsRef.current.has(eventId)) {
          triggeredEventsRef.current.add(eventId);

          // Play reminder beep
          if (!settings.soundMuted) {
            audioSynth.playReminderBeep(reminder.soundType, settings.globalVolume);
          }

          // Trigger screen alert banner
          setActiveAlert({
            prayerKey: prayer.key,
            prayerName: prayer.englishName,
            type: 'adhan',
            minutesLeft: reminder.minutesBeforeAdhan,
            message: `${reminder.minutesBeforeAdhan} minute${
              reminder.minutesBeforeAdhan > 1 ? 's' : ''
            } until ${prayer.englishName} Adhan`,
            timestamp: Date.now(),
          });
        }
      }
    }

    // 2. Check Pre-Iqamah Reminder
    if (settings.enablePreIqamahBeep && settings.preIqamahMinutes > 0) {
      for (const prayer of prayerData.prayerList) {
        if (!prayer.iqamahTimeDate) continue;
        const iqMs = prayer.iqamahTimeDate.getTime();
        const diffMs = iqMs - nowMs;
        const targetWindowMs = settings.preIqamahMinutes * 60 * 1000;

        if (diffMs > 0 && diffMs <= targetWindowMs && diffMs >= targetWindowMs - 2500) {
          const eventId = `iqamah-${prayer.key}-${dateStr}-${settings.preIqamahMinutes}m`;
          if (!triggeredEventsRef.current.has(eventId)) {
            triggeredEventsRef.current.add(eventId);

            if (!settings.soundMuted) {
              audioSynth.playIqamahReminder(settings.globalVolume);
            }

            setActiveAlert({
              prayerKey: prayer.key,
              prayerName: prayer.englishName,
              type: 'iqamah',
              minutesLeft: settings.preIqamahMinutes,
              message: `Iqamah for ${prayer.englishName} in ${settings.preIqamahMinutes} minute${
                settings.preIqamahMinutes > 1 ? 's' : ''
              } - Please prepare rows`,
              timestamp: Date.now(),
            });
          }
        }
      }
    }

    // Clean old event entries once a day
    if (triggeredEventsRef.current.size > 50) {
      triggeredEventsRef.current.clear();
    }
  }, [now, prayerData, settings]);

  // Dismiss active alert automatically after 20 seconds
  useEffect(() => {
    if (!activeAlert) return;
    const timeout = setTimeout(() => {
      setActiveAlert(null);
    }, 20000);
    return () => clearTimeout(timeout);
  }, [activeAlert]);

  const unlockAudio = useCallback(() => {
    const success = audioSynth.unlock();
    setAudioUnlocked(success);
  }, []);

  const triggerTestSound = useCallback(
    (soundType = settings.reminders.dhuhr.soundType) => {
      audioSynth.unlock();
      setAudioUnlocked(true);
      audioSynth.playReminderBeep(soundType, settings.globalVolume);
    },
    [settings]
  );

  const dismissAlert = useCallback(() => {
    setActiveAlert(null);
  }, []);

  return {
    now,
    prayerData,
    activeAlert,
    dismissAlert,
    audioUnlocked,
    unlockAudio,
    triggerTestSound,
  };
}
