export type PrayerKey = 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export type CalculationMethodId =
  | 'MWL' // Muslim World League
  | 'ISNA' // Islamic Society of North America
  | 'Egypt' // Egyptian General Authority of Survey
  | 'Makkah' // Umm al-Qura University, Makkah
  | 'Karachi' // University of Islamic Sciences, Karachi
  | 'Tehran' // Institute of Geophysics, Tehran
  | 'Gulf' // Dubai / Gulf Awqaf
  | 'Turkey' // Diyanet İşleri Başkanlığı
  | 'Singapore' // Majlis Ugama Islam Singapura (MUIS)
  | 'France' // Union des Organisations Islamiques de France (UOIF 12°)
  | 'Custom';

export type JuristicMethod = 'Standard' | 'Hanafi'; // Standard = Shafi'i, Maliki, Hanbali (shadow factor 1), Hanafi (factor 2)

export type HighLatitudeRule = 'NightMiddle' | 'OneSeventh' | 'AngleBased';

export type SoundType = 'beep_classic' | 'beep_soft_chime' | 'beep_double_pip' | 'beep_pulsed';

export type DisplayTheme = 'classic-masjid-emerald' | 'royal-amber-night' | 'modern-minimal-slate' | 'vibrant-digital-led';

export interface LocationConfig {
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  timezone: number; // UTC offset in hours (e.g. +3, -5, +5.5)
  autoDetectTimezone: boolean;
  elevation: number; // meters above sea level
}

export interface PrayerReminderSetting {
  enabled: boolean;
  minutesBeforeAdhan: number; // Default 1 min as requested, customizable e.g. 1, 2, 5, 10, 15
  soundType: SoundType;
}

export interface IqamahSetting {
  type: 'offset' | 'fixed';
  offsetMinutes: number; // e.g. 15 min after adhan
  fixedTime: string; // e.g. "13:30" (for Dhuhr or Isha)
  roundToNearest5: boolean;
}

export interface PrayerTimeOverride {
  enabled: boolean; // true = user fixed override; false = auto seasonal calculation
  adhanTime: string; // "HH:MM" e.g. "05:15"
  iqamahTime?: string; // "HH:MM" e.g. "05:45"
}

export interface MosqueSettings {
  mosqueName: string;
  mosqueArabicName: string;
  hallName: string;
  theme: DisplayTheme;
  timeFormat: '12h' | '24h';
  showSeconds: boolean;
  method: CalculationMethodId;
  juristic: JuristicMethod;
  highLatitudeRule: HighLatitudeRule;
  hijriOffsetDays: number; // -2 to +2 for moon sighting adjustment
  location: LocationConfig;
  manualOffsets: Record<PrayerKey, number>; // +/- minutes fine-tuning
  reminders: Record<PrayerKey, PrayerReminderSetting>;
  globalVolume: number; // 0 to 1
  soundMuted: boolean;
  iqamahSettings: Record<PrayerKey, IqamahSetting>;
  // JUMMA PRAYER TIMINGS
  jumuaAdhanTime: string; // e.g. "12:30" (1st Adhan)
  jumuaKhutbahTime: string; // e.g. "12:45" (Khutbah / 2nd Adhan)
  jumuaTime: string; // e.g. "13:15" (Jumma Salah Congregation)
  timeOverrides: Record<PrayerKey, PrayerTimeOverride>;
  enablePreIqamahBeep: boolean;
  preIqamahMinutes: number; // e.g. 2 min before Iqamah
  salahDurationMinutes: number; // e.g. 15 min for "Please silence your phones" screen
  announcements: string[];
  showExtraTimes: boolean; // Tahajjud, Suhoor/Imsak, Ishraq
  // MOSQUE LEADERSHIP
  imamName: string; // e.g. "হাফেজ মাওলানা মোঃ ক্বারী সাহেব"
  presidentName: string; // e.g. "জনাব মোঃ সভাপতি সাহেব"
  showLeadership: boolean; // toggle displaying on board
}

export interface SinglePrayerTime {
  key: PrayerKey;
  englishName: string;
  bengaliName: string;
  arabicName: string;
  transliteration: string;
  timeDate: Date;
  adhanTimeFormatted: string;
  iqamahTimeDate: Date | null;
  iqamahTimeFormatted: string;
  isPassed: boolean;
  isCurrent: boolean;
  isNext: boolean;
  reminderMinutes: number;
  reminderEnabled: boolean;
  isCustomOverride?: boolean;
}

export interface ExtraTimes {
  imsak: { timeDate: Date; formatted: string };
  ishraq: { timeDate: Date; formatted: string };
  duha: { timeDate: Date; formatted: string };
  midnight: { timeDate: Date; formatted: string };
  tahajjud: { timeDate: Date; formatted: string }; // Last 1/3rd of the night
}

export interface DailyPrayerTimes {
  date: Date;
  prayers: Record<PrayerKey, SinglePrayerTime>;
  prayerList: SinglePrayerTime[];
  extras: ExtraTimes;
  currentPrayerKey: PrayerKey | null;
  nextPrayerKey: PrayerKey;
  nextEvent: {
    type: 'adhan' | 'iqamah';
    prayerKey: PrayerKey;
    targetTime: Date;
    remainingMs: number;
  };
  isInSalahWindow: boolean; // Mobile phone silence reminder mode
  activeSalahKey: PrayerKey | null;
}
