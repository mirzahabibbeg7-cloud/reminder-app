import {
  CalculationMethodId,
  JuristicMethod,
  HighLatitudeRule,
  PrayerKey,
  LocationConfig,
  MosqueSettings,
  SinglePrayerTime,
  DailyPrayerTimes,
  ExtraTimes,
} from '../types/prayer';

// Method parameters: [Fajr Angle, Isha Angle or 0 if fixed minutes, ishaIntervalMin (0 if angle)]
export interface MethodParams {
  name: string;
  fajrAngle: number;
  ishaAngle: number;
  ishaIntervalMinutes?: number;
  maghribAngle?: number;
  maghribIntervalMinutes?: number;
}

export const CALCULATION_METHODS: Record<CalculationMethodId, MethodParams> = {
  MWL: {
    name: 'Muslim World League (MWL)',
    fajrAngle: 18.0,
    ishaAngle: 17.0,
  },
  ISNA: {
    name: 'Islamic Society of North America (ISNA)',
    fajrAngle: 15.0,
    ishaAngle: 15.0,
  },
  Egypt: {
    name: 'Egyptian General Authority of Survey',
    fajrAngle: 19.5,
    ishaAngle: 17.5,
  },
  Makkah: {
    name: 'Umm Al-Qura University, Makkah',
    fajrAngle: 18.5,
    ishaAngle: 0,
    ishaIntervalMinutes: 90,
  },
  Karachi: {
    name: 'Univ. of Islamic Sciences, Karachi',
    fajrAngle: 18.0,
    ishaAngle: 18.0,
  },
  Tehran: {
    name: 'Institute of Geophysics, Tehran',
    fajrAngle: 17.7,
    maghribAngle: 4.5,
    ishaAngle: 14.0,
  },
  Gulf: {
    name: 'Gulf / Dubai Islamic Affairs',
    fajrAngle: 18.2,
    ishaAngle: 0,
    ishaIntervalMinutes: 90,
  },
  Turkey: {
    name: 'Diyanet İşleri Başkanlığı (Turkey)',
    fajrAngle: 18.0,
    ishaAngle: 17.0,
  },
  Singapore: {
    name: 'MUIS (Singapore / SE Asia)',
    fajrAngle: 20.0,
    ishaAngle: 18.0,
  },
  France: {
    name: 'UOIF (France 12°)',
    fajrAngle: 12.0,
    ishaAngle: 12.0,
  },
  Custom: {
    name: 'Custom Angle Parameters',
    fajrAngle: 18.0,
    ishaAngle: 17.0,
  },
};

export const POPULAR_CITIES: LocationConfig[] = [
  { city: 'Bandarbani (PIN 721504)', country: 'India', latitude: 22.5057, longitude: 86.9922, timezone: 5.5, autoDetectTimezone: true, elevation: 85 },
  { city: 'Jhargram', country: 'India', latitude: 22.4500, longitude: 86.9833, timezone: 5.5, autoDetectTimezone: true, elevation: 81 },
  { city: 'Kolkata', country: 'India', latitude: 22.5726, longitude: 88.3639, timezone: 5.5, autoDetectTimezone: true, elevation: 9 },
  { city: 'Midnapore', country: 'India', latitude: 22.4257, longitude: 87.3199, timezone: 5.5, autoDetectTimezone: true, elevation: 23 },
  { city: 'Makkah', country: 'Saudi Arabia', latitude: 21.4225, longitude: 39.8262, timezone: 3, autoDetectTimezone: false, elevation: 277 },
  { city: 'Madinah', country: 'Saudi Arabia', latitude: 24.4672, longitude: 39.6112, timezone: 3, autoDetectTimezone: false, elevation: 608 },
  { city: 'Jerusalem', country: 'Palestine', latitude: 31.7683, longitude: 35.2137, timezone: 3, autoDetectTimezone: false, elevation: 754 },
  { city: 'Cairo', country: 'Egypt', latitude: 30.0444, longitude: 31.2357, timezone: 3, autoDetectTimezone: false, elevation: 23 },
  { city: 'Istanbul', country: 'Turkey', latitude: 41.0082, longitude: 28.9784, timezone: 3, autoDetectTimezone: false, elevation: 39 },
  { city: 'London', country: 'United Kingdom', latitude: 51.5074, longitude: -0.1278, timezone: 1, autoDetectTimezone: true, elevation: 11 },
  { city: 'New York', country: 'United States', latitude: 40.7128, longitude: -74.006, timezone: -4, autoDetectTimezone: true, elevation: 10 },
  { city: 'Chicago', country: 'United States', latitude: 41.8781, longitude: -87.6298, timezone: -5, autoDetectTimezone: true, elevation: 181 },
  { city: 'Toronto', country: 'Canada', latitude: 43.6532, longitude: -79.3832, timezone: -4, autoDetectTimezone: true, elevation: 76 },
  { city: 'Karachi', country: 'Pakistan', latitude: 24.8607, longitude: 67.0011, timezone: 5, autoDetectTimezone: false, elevation: 8 },
  { city: 'Lahore', country: 'Pakistan', latitude: 31.5204, longitude: 74.3587, timezone: 5, autoDetectTimezone: false, elevation: 217 },
  { city: 'Dhaka', country: 'Bangladesh', latitude: 23.8103, longitude: 90.4125, timezone: 6, autoDetectTimezone: false, elevation: 4 },
  { city: 'Jakarta', country: 'Indonesia', latitude: -6.2088, longitude: 106.8456, timezone: 7, autoDetectTimezone: false, elevation: 8 },
  { city: 'Kuala Lumpur', country: 'Malaysia', latitude: 3.139, longitude: 101.6869, timezone: 8, autoDetectTimezone: false, elevation: 22 },
  { city: 'Dubai', country: 'United Arab Emirates', latitude: 25.2048, longitude: 55.2708, timezone: 4, autoDetectTimezone: false, elevation: 5 },
  { city: 'Doha', country: 'Qatar', latitude: 25.2854, longitude: 51.531, timezone: 3, autoDetectTimezone: false, elevation: 10 },
  { city: 'Paris', country: 'France', latitude: 48.8566, longitude: 2.3522, timezone: 2, autoDetectTimezone: true, elevation: 35 },
  { city: 'Berlin', country: 'Germany', latitude: 52.52, longitude: 13.405, timezone: 2, autoDetectTimezone: true, elevation: 34 },
  { city: 'Sydney', country: 'Australia', latitude: -33.8688, longitude: 151.2093, timezone: 10, autoDetectTimezone: true, elevation: 19 },
  { city: 'Cape Town', country: 'South Africa', latitude: -33.9249, longitude: 18.4241, timezone: 2, autoDetectTimezone: false, elevation: 42 },
];

// Mathematical Helper Functions
const degToRad = (d: number) => (d * Math.PI) / 180.0;
const radToDeg = (r: number) => (r * 180.0) / Math.PI;

const fixAngle = (a: number) => {
  a = a - 360.0 * Math.floor(a / 360.0);
  return a < 0 ? a + 360.0 : a;
};

const fixHour = (h: number) => {
  h = h - 24.0 * Math.floor(h / 24.0);
  return h < 0 ? h + 24.0 : h;
};

// Calculate Julian Day for given Gregorian date
export function getJulianDay(year: number, month: number, day: number): number {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return (
    Math.floor(365.25 * (year + 4716)) +
    Math.floor(30.6001 * (month + 1)) +
    day +
    B -
    1524.5
  );
}

// Compute Sun's position: Declination and Equation of Time
export function getSunPosition(julianDay: number) {
  const D = julianDay - 2451545.0;
  const g = fixAngle(357.529 + 0.98560028 * D);
  const q = fixAngle(280.459 + 0.98564736 * D);
  const L = fixAngle(q + 1.915 * Math.sin(degToRad(g)) + 0.02 * Math.sin(degToRad(2 * g)));

  const e = 23.439 - 0.00000036 * D;
  const d = radToDeg(Math.asin(Math.sin(degToRad(e)) * Math.sin(degToRad(L))));

  let RA = radToDeg(Math.atan2(Math.cos(degToRad(e)) * Math.sin(degToRad(L)), Math.cos(degToRad(L)))) / 15;
  RA = fixHour(RA);

  const EqT = q / 15 - RA;
  return { declination: d, equationOfTime: EqT };
}

// Compute Solar Midday (Noon / Dhuhr base)
export function getMidday(timezone: number, longitude: number, equationOfTime: number): number {
  return fixHour(12 + timezone - longitude / 15 - equationOfTime);
}

// Compute hour angle for a given solar altitude angle
export function getHourAngle(altitude: number, latitude: number, declination: number): number {
  const latRad = degToRad(latitude);
  const decRad = degToRad(declination);
  const altRad = degToRad(altitude);

  const cosH = (Math.sin(altRad) - Math.sin(latRad) * Math.sin(decRad)) / (Math.cos(latRad) * Math.cos(decRad));

  if (cosH > 1.0) return 0; // Sun never rises to this altitude
  if (cosH < -1.0) return 180; // Sun never sets below this altitude

  return radToDeg(Math.acos(cosH));
}

// Compute solar altitude for Asr based on juristic method
export function getAsrAltitude(juristic: JuristicMethod, latitude: number, declination: number): number {
  const factor = juristic === 'Hanafi' ? 2 : 1;
  const delta = Math.abs(latitude - declination);
  return radToDeg(Math.atan(1 / (factor + Math.tan(degToRad(delta)))));
}

// High latitude adjustment rules
export function adjustHighLatitude(
  timeHours: number,
  baseHours: number,
  nightLengthHours: number,
  angle: number,
  direction: 'ccw' | 'cw',
  rule: HighLatitudeRule
): number {
  let portion = 0.5; // default Middle of Night
  if (rule === 'OneSeventh') {
    portion = 1 / 7;
  } else if (rule === 'AngleBased') {
    portion = angle / 60;
  }

  const maxDiff = portion * nightLengthHours;
  const currentDiff = direction === 'ccw' ? baseHours - timeHours : timeHours - baseHours;

  if (isNaN(timeHours) || currentDiff > maxDiff || currentDiff < 0) {
    return direction === 'ccw' ? baseHours - maxDiff : baseHours + maxDiff;
  }
  return timeHours;
}

// Convert decimal hours (e.g. 14.75) to Date object on target date
export function hoursToDate(baseDate: Date, decimalHours: number): Date {
  const d = new Date(baseDate);
  const normalized = fixHour(decimalHours);
  const hours = Math.floor(normalized);
  const remainderMinutes = (normalized - hours) * 60;
  const minutes = Math.floor(remainderMinutes);
  const seconds = Math.floor((remainderMinutes - minutes) * 60);

  d.setHours(hours, minutes, seconds, 0);
  return d;
}

// Format time nicely in 12h or 24h
export function formatPrayerTime(
  date: Date,
  format: '12h' | '24h' = '12h',
  showSeconds: boolean = false
): string {
  if (isNaN(date.getTime())) return '--:--';
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  const pad = (n: number) => n.toString().padStart(2, '0');

  if (format === '24h') {
    return showSeconds
      ? `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
      : `${pad(hours)}:${pad(minutes)}`;
  }

  const period = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 === 0 ? 12 : hours % 12;
  return showSeconds
    ? `${displayHours}:${pad(minutes)}:${pad(seconds)} ${period}`
    : `${displayHours}:${pad(minutes)} ${period}`;
}

export function formatRemainingTime(ms: number): {
  hours: number;
  minutes: number;
  seconds: number;
  formatted: string;
} {
  if (ms <= 0) return { hours: 0, minutes: 0, seconds: 0, formatted: '00:00:00' };
  const totalSec = Math.floor(ms / 1000);
  const hours = Math.floor(totalSec / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;

  const pad = (n: number) => n.toString().padStart(2, '0');
  const formatted =
    hours > 0
      ? `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
      : `${pad(minutes)}:${pad(seconds)}`;

  return { hours, minutes, seconds, formatted };
}

// Main Calculation Function for a specific Date & Settings
export function calculateDailyPrayerTimes(
  date: Date,
  settings: MosqueSettings
): DailyPrayerTimes {
  const { location, method, juristic, highLatitudeRule, manualOffsets, reminders, iqamahSettings } =
    settings;
  const methodParams = CALCULATION_METHODS[method] || CALCULATION_METHODS.MWL;

  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  // Effective timezone offset
  const timezone = location.autoDetectTimezone
    ? -date.getTimezoneOffset() / 60
    : location.timezone;

  const jd = getJulianDay(year, month, day);
  const { declination, equationOfTime } = getSunPosition(jd);

  // Solar Midday
  const midday = getMidday(timezone, location.longitude, equationOfTime);

  // Sunrise and Sunset (altitude -0.833° with elevation correction)
  const elevationCorrection = 0.0347 * Math.sqrt(Math.max(0, location.elevation));
  const horizonAngle = -0.8333 - elevationCorrection;
  const sunHalfDay = getHourAngle(horizonAngle, location.latitude, declination);

  const sunriseHours = midday - sunHalfDay / 15;
  const sunsetHours = midday + sunHalfDay / 15;
  const nightLength = 24 - (sunsetHours - sunriseHours);

  // 1. Fajr
  let fajrHA = getHourAngle(-methodParams.fajrAngle, location.latitude, declination);
  let fajrHours = fajrHA > 0 ? midday - fajrHA / 15 : NaN;
  fajrHours = adjustHighLatitude(fajrHours, sunriseHours, nightLength, methodParams.fajrAngle, 'ccw', highLatitudeRule);

  // 2. Dhuhr (solar noon + 1 minute zawal safety)
  const dhuhrHours = midday + 1 / 60;

  // 3. Asr
  const asrAltitude = getAsrAltitude(juristic, location.latitude, declination);
  const asrHA = getHourAngle(asrAltitude, location.latitude, declination);
  const asrHours = midday + asrHA / 15;

  // 4. Maghrib
  let maghribHours = sunsetHours;
  if (methodParams.maghribAngle) {
    const maghribHA = getHourAngle(-methodParams.maghribAngle, location.latitude, declination);
    maghribHours = midday + maghribHA / 15;
  } else if (methodParams.maghribIntervalMinutes) {
    maghribHours = sunsetHours + methodParams.maghribIntervalMinutes / 60;
  }

  // 5. Isha
  let ishaHours: number;
  if (methodParams.ishaIntervalMinutes && methodParams.ishaIntervalMinutes > 0) {
    ishaHours = maghribHours + methodParams.ishaIntervalMinutes / 60;
  } else {
    let ishaHA = getHourAngle(-methodParams.ishaAngle, location.latitude, declination);
    ishaHours = ishaHA > 0 ? midday + ishaHA / 15 : NaN;
    ishaHours = adjustHighLatitude(ishaHours, sunsetHours, nightLength, methodParams.ishaAngle, 'cw', highLatitudeRule);
  }

  // Apply manual offsets in minutes
  const applyOffset = (h: number, key: PrayerKey) => {
    const offsetMin = manualOffsets[key] || 0;
    return h + offsetMin / 60;
  };

  const rawTimes: Record<PrayerKey, number> = {
    fajr: applyOffset(fajrHours, 'fajr'),
    sunrise: applyOffset(sunriseHours, 'sunrise'),
    dhuhr: applyOffset(dhuhrHours, 'dhuhr'),
    asr: applyOffset(asrHours, 'asr'),
    maghrib: applyOffset(maghribHours, 'maghrib'),
    isha: applyOffset(ishaHours, 'isha'),
  };

  // Convert raw decimal hours to full Date objects
  const timeDates: Record<PrayerKey, Date> = {
    fajr: hoursToDate(date, rawTimes.fajr),
    sunrise: hoursToDate(date, rawTimes.sunrise),
    dhuhr: hoursToDate(date, rawTimes.dhuhr),
    asr: hoursToDate(date, rawTimes.asr),
    maghrib: hoursToDate(date, rawTimes.maghrib),
    isha: hoursToDate(date, rawTimes.isha),
  };

  const keys: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  // Check for User Custom Time Overrides (Adhan Time)
  const isFriday = date.getDay() === 5;
  const timeOverrides = settings.timeOverrides || {};

  keys.forEach((k) => {
    const override = timeOverrides[k];
    if (override && override.enabled && override.adhanTime) {
      const [h, m] = override.adhanTime.split(':').map(Number);
      if (!isNaN(h) && !isNaN(m)) {
        const customD = new Date(date);
        customD.setHours(h, m, 0, 0);
        timeDates[k] = customD;
      }
    } else if (k === 'dhuhr' && isFriday && settings.jumuaAdhanTime) {
      // On Friday, if Jumma Adhan time is set, Dhuhr Adhan aligns with Jumma 1st Adhan
      const [h, m] = settings.jumuaAdhanTime.split(':').map(Number);
      if (!isNaN(h) && !isNaN(m)) {
        const jumuaD = new Date(date);
        jumuaD.setHours(h, m, 0, 0);
        timeDates[k] = jumuaD;
      }
    }
  });

  // Calculate Iqamah times
  const computeIqamah = (key: PrayerKey, adhanDate: Date): Date => {
    // If user has a custom override for Iqamah
    const override = timeOverrides[key];
    if (override && override.enabled && override.iqamahTime) {
      const [h, m] = override.iqamahTime.split(':').map(Number);
      if (!isNaN(h) && !isNaN(m)) {
        const customIq = new Date(date);
        customIq.setHours(h, m, 0, 0);
        return customIq;
      }
    }

    // Friday Dhuhr / Jumma Congregation
    if (key === 'dhuhr' && isFriday && settings.jumuaTime) {
      const [h, m] = settings.jumuaTime.split(':').map(Number);
      if (!isNaN(h) && !isNaN(m)) {
        const jIq = new Date(date);
        jIq.setHours(h, m, 0, 0);
        return jIq;
      }
    }

    const cfg = iqamahSettings[key];
    if (!cfg) {
      return new Date(adhanDate.getTime() + 15 * 60000);
    }
    if (cfg.type === 'fixed' && cfg.fixedTime) {
      const [fH, fM] = cfg.fixedTime.split(':').map(Number);
      const fixedD = new Date(date);
      fixedD.setHours(fH, fM, 0, 0);
      return fixedD;
    }
    // Offset mode
    let targetMs = adhanDate.getTime() + cfg.offsetMinutes * 60000;
    if (cfg.roundToNearest5) {
      const d = new Date(targetMs);
      const mins = d.getMinutes();
      const rounded = Math.ceil(mins / 5) * 5;
      d.setMinutes(rounded, 0, 0);
      return d;
    }
    return new Date(targetMs);
  };

  const prayerMetadata: Record<
    PrayerKey,
    { english: string; bengali: string; arabic: string; transliteration: string }
  > = {
    fajr: { english: 'Dawn', bengali: 'ফজর', arabic: 'الفجر', transliteration: 'ফজর' },
    sunrise: { english: 'Sunrise', bengali: 'সূর্যোদয়', arabic: 'الشروق', transliteration: 'সূর্যোদয়' },
    dhuhr: { english: 'Noon', bengali: 'যোহর', arabic: 'الظهر', transliteration: 'যোহর' },
    asr: { english: 'Afternoon', bengali: 'আসর', arabic: 'العصر', transliteration: 'আসর' },
    maghrib: { english: 'Sunset', bengali: 'মাগরিব', arabic: 'المغرب', transliteration: 'মাগরিব' },
    isha: { english: 'Night', bengali: 'এশা', arabic: 'العشاء', transliteration: 'এশা' },
  };

  const now = date;
  const nowMs = now.getTime();

  // Extra times: Imsak (Fajr - 10m), Ishraq (Sunrise + 15m), Duha, Midnight, Tahajjud
  const imsakDate = new Date(timeDates.fajr.getTime() - 10 * 60000);
  const ishraqDate = new Date(timeDates.sunrise.getTime() + 15 * 60000);
  const duhaDate = new Date(timeDates.sunrise.getTime() + 45 * 60000);
  // Midnight is midpoint between Sunset and Sunrise
  const midnightMs = timeDates.maghrib.getTime() + (nightLength * 3600000) / 2;
  const midnightDate = new Date(midnightMs);
  // Tahajjud: last third of the night
  const tahajjudMs = timeDates.maghrib.getTime() + ((nightLength * 2) / 3) * 3600000;
  const tahajjudDate = new Date(tahajjudMs);

  const extras: ExtraTimes = {
    imsak: { timeDate: imsakDate, formatted: formatPrayerTime(imsakDate, settings.timeFormat) },
    ishraq: { timeDate: ishraqDate, formatted: formatPrayerTime(ishraqDate, settings.timeFormat) },
    duha: { timeDate: duhaDate, formatted: formatPrayerTime(duhaDate, settings.timeFormat) },
    midnight: { timeDate: midnightDate, formatted: formatPrayerTime(midnightDate, settings.timeFormat) },
    tahajjud: { timeDate: tahajjudDate, formatted: formatPrayerTime(tahajjudDate, settings.timeFormat) },
  };

  // Determine current prayer and next prayer
  let currentKey: PrayerKey | null = null;
  let nextKey: PrayerKey = 'fajr';

  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    if (nowMs >= timeDates[k].getTime()) {
      currentKey = k;
    }
  }

  // Next prayer
  const upcomingKey = keys.find((k) => timeDates[k].getTime() > nowMs);
  if (upcomingKey) {
    nextKey = upcomingKey;
  } else {
    // Tomorrow Fajr is next!
    nextKey = 'fajr';
  }

  // Construct single prayer objects
  const prayers = {} as Record<PrayerKey, SinglePrayerTime>;
  const prayerList: SinglePrayerTime[] = [];

  for (const k of keys) {
    const adhanDate = timeDates[k];
    const isPassed = nowMs > adhanDate.getTime();
    const isCurrent = currentKey === k;
    const isNext = nextKey === k;

    // Iqamah does not apply to Sunrise
    const iqamahDate = k === 'sunrise' ? null : computeIqamah(k, adhanDate);

    const prayerObj: SinglePrayerTime = {
      key: k,
      englishName: prayerMetadata[k].english,
      bengaliName: prayerMetadata[k].bengali,
      arabicName: prayerMetadata[k].arabic,
      transliteration: prayerMetadata[k].transliteration,
      timeDate: adhanDate,
      adhanTimeFormatted: formatPrayerTime(adhanDate, settings.timeFormat),
      iqamahTimeDate: iqamahDate,
      iqamahTimeFormatted: iqamahDate
        ? formatPrayerTime(iqamahDate, settings.timeFormat)
        : '--',
      isPassed,
      isCurrent,
      isNext,
      reminderMinutes: reminders[k]?.minutesBeforeAdhan ?? 1,
      reminderEnabled: reminders[k]?.enabled ?? true,
      isCustomOverride: !!timeOverrides[k]?.enabled,
    };

    prayers[k] = prayerObj;
    prayerList.push(prayerObj);
  }

  // Check if inside Salah Window (between Iqamah and Iqamah + salahDurationMinutes)
  let isInSalahWindow = false;
  let activeSalahKey: PrayerKey | null = null;

  for (const k of ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as PrayerKey[]) {
    const iqDate = prayers[k].iqamahTimeDate;
    if (iqDate) {
      const iqMs = iqDate.getTime();
      const endMs = iqMs + settings.salahDurationMinutes * 60000;
      if (nowMs >= iqMs && nowMs <= endMs) {
        isInSalahWindow = true;
        activeSalahKey = k;
        break;
      }
    }
  }

  // Determine Next Event (Adhan or Iqamah)
  // If we are between Adhan and Iqamah for current prayer, next event is Iqamah!
  let nextEventType: 'adhan' | 'iqamah' = 'adhan';
  let targetTime: Date = timeDates[nextKey];
  let eventPrayerKey = nextKey;

  if (currentKey && currentKey !== 'sunrise') {
    const currentIq = prayers[currentKey].iqamahTimeDate;
    if (currentIq && nowMs < currentIq.getTime()) {
      nextEventType = 'iqamah';
      targetTime = currentIq;
      eventPrayerKey = currentKey;
    }
  }

  // If next is tomorrow's Fajr (targetTime is in the past)
  if (targetTime.getTime() <= nowMs) {
    // Tomorrow Fajr
    const tomorrow = new Date(date);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowCalcs = calculateDailyPrayerTimes(tomorrow, settings);
    targetTime = tomorrowCalcs.prayers.fajr.timeDate;
    eventPrayerKey = 'fajr';
  }

  const remainingMs = Math.max(0, targetTime.getTime() - nowMs);

  return {
    date,
    prayers,
    prayerList,
    extras,
    currentPrayerKey: currentKey,
    nextPrayerKey: nextKey,
    nextEvent: {
      type: nextEventType,
      prayerKey: eventPrayerKey,
      targetTime,
      remainingMs,
    },
    isInSalahWindow,
    activeSalahKey,
  };
}

// Generate Seasonal Shift comparison across 4 Solstices / Equinoxes
export interface SeasonalShiftPoint {
  seasonName: string;
  seasonArabic: string;
  dateStr: string;
  date: Date;
  dayLengthHours: number;
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

export function calculateSeasonalShifts(
  currentYear: number,
  settings: MosqueSettings
): SeasonalShiftPoint[] {
  const dates = [
    { name: 'Spring Equinox', arabic: 'الاعتدال الربيعي', month: 2, day: 20 }, // Mar 20
    { name: 'Summer Solstice', arabic: 'الانقلاب الصيفي', month: 5, day: 21 }, // Jun 21 (longest day)
    { name: 'Autumn Equinox', arabic: 'الاعتدال الخريفي', month: 8, day: 22 }, // Sep 22
    { name: 'Winter Solstice', arabic: 'الانقلاب الشتوي', month: 11, day: 21 }, // Dec 21 (shortest day)
  ];

  return dates.map((item) => {
    const d = new Date(currentYear, item.month, item.day, 12, 0, 0);
    const times = calculateDailyPrayerTimes(d, settings);
    const sunriseMs = times.prayers.sunrise.timeDate.getTime();
    const sunsetMs = times.prayers.maghrib.timeDate.getTime();
    const dayLengthHours = Math.round(((sunsetMs - sunriseMs) / 3600000) * 10) / 10;

    return {
      seasonName: item.name,
      seasonArabic: item.arabic,
      dateStr: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      date: d,
      dayLengthHours,
      fajr: times.prayers.fajr.adhanTimeFormatted,
      sunrise: times.prayers.sunrise.adhanTimeFormatted,
      dhuhr: times.prayers.dhuhr.adhanTimeFormatted,
      asr: times.prayers.asr.adhanTimeFormatted,
      maghrib: times.prayers.maghrib.adhanTimeFormatted,
      isha: times.prayers.isha.adhanTimeFormatted,
    };
  });
}
