import { SoundType } from '../types/prayer';

class AudioSynthesizer {
  private ctx: AudioContext | null = null;
  private isUnlocked: boolean = false;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock(): boolean {
    const ctx = this.getContext();
    if (!ctx) return false;
    if (ctx.state === 'suspended') {
      ctx.resume().then(() => {
        this.isUnlocked = true;
      });
    } else {
      this.isUnlocked = true;
    }
    return this.isUnlocked;
  }

  public getUnlockedStatus(): boolean {
    if (!this.ctx) return false;
    return this.ctx.state === 'running';
  }

  /**
   * Plays the designated reminder beep sound
   */
  public playReminderBeep(
    soundType: SoundType = 'beep_classic',
    volume: number = 0.8
  ): void {
    const ctx = this.getContext();
    if (!ctx) return;

    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const masterGain = ctx.createGain();
    const clampedVolume = Math.max(0, Math.min(1, volume));
    masterGain.gain.setValueAtTime(clampedVolume, ctx.currentTime);
    masterGain.connect(ctx.destination);

    const now = ctx.currentTime;

    switch (soundType) {
      case 'beep_classic': {
        // Classic Mosque Digital Clock: 3 short warning pips (880Hz) + 1 longer confirmation beep (1050Hz)
        const pips = [
          { time: now + 0.0, freq: 880, dur: 0.12 },
          { time: now + 0.28, freq: 880, dur: 0.12 },
          { time: now + 0.56, freq: 880, dur: 0.12 },
          { time: now + 0.84, freq: 1046.5, dur: 0.45 },
        ];

        pips.forEach(({ time, freq, dur }) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, time);

          gain.gain.setValueAtTime(0, time);
          gain.gain.linearRampToValueAtTime(0.85, time + 0.015);
          gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(time);
          osc.stop(time + dur);
        });
        break;
      }

      case 'beep_soft_chime': {
        // Resonant prayer bell chime (harmonic sine waves with gentle decay)
        const baseFreq = 528; // Harmonic tone
        const harmonics = [1, 2, 3];

        harmonics.forEach((h, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = idx === 0 ? 'sine' : 'triangle';
          osc.frequency.setValueAtTime(baseFreq * h, now);

          const peakGain = 0.6 / (idx + 1);
          gain.gain.setValueAtTime(0, now);
          gain.gain.linearRampToValueAtTime(peakGain, now + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(now);
          osc.stop(now + 1.8);
        });
        break;
      }

      case 'beep_double_pip': {
        // Dual clear digital pulses: 900Hz -> 1200Hz
        const pulses = [
          { time: now, freq: 900 },
          { time: now + 0.18, freq: 1200 },
        ];

        pulses.forEach(({ time, freq }) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, time);

          gain.gain.setValueAtTime(0, time);
          gain.gain.linearRampToValueAtTime(0.9, time + 0.01);
          gain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(time);
          osc.stop(time + 0.13);
        });
        break;
      }

      case 'beep_pulsed': {
        // Rapid 3-pulse cadence with warm resonance
        const pulseTimes = [0, 0.2, 0.4];
        pulseTimes.forEach((t) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(740, now + t);

          gain.gain.setValueAtTime(0, now + t);
          gain.gain.linearRampToValueAtTime(0.7, now + t + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.001, now + t + 0.14);

          osc.connect(gain);
          gain.connect(masterGain);

          osc.start(now + t);
          osc.stop(now + t + 0.15);
        });
        break;
      }
    }
  }

  /**
   * Pre-Iqamah soft alert (call to line up for congregation)
   */
  public playIqamahReminder(volume: number = 0.7): void {
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume();

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(Math.min(1, volume), ctx.currentTime);
    masterGain.connect(ctx.destination);

    const now = ctx.currentTime;
    // Two gentle warm low-chimes
    [0, 0.4].forEach((offset, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(i === 0 ? 660 : 880, now + offset);

      gain.gain.setValueAtTime(0, now + offset);
      gain.gain.linearRampToValueAtTime(0.75, now + offset + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.35);

      osc.connect(gain);
      gain.connect(masterGain);

      osc.start(now + offset);
      osc.stop(now + offset + 0.36);
    });
  }
}

export const audioSynth = new AudioSynthesizer();
