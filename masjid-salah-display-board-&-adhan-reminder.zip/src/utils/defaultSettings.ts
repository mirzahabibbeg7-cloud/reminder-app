import { MosqueSettings, PrayerKey, PrayerReminderSetting, IqamahSetting } from '../types/prayer';

const defaultReminders: Record<PrayerKey, PrayerReminderSetting> = {
  fajr: { enabled: true, minutesBeforeAdhan: 5, soundType: 'beep_classic' }, // Often 5 min for Suhoor/Fajr prep
  sunrise: { enabled: false, minutesBeforeAdhan: 1, soundType: 'beep_classic' },
  dhuhr: { enabled: true, minutesBeforeAdhan: 1, soundType: 'beep_classic' }, // 1 min as requested
  asr: { enabled: true, minutesBeforeAdhan: 1, soundType: 'beep_classic' },   // 1 min as requested
  maghrib: { enabled: true, minutesBeforeAdhan: 1, soundType: 'beep_classic' },// 1 min as requested
  isha: { enabled: true, minutesBeforeAdhan: 1, soundType: 'beep_classic' },   // 1 min as requested
};

const defaultIqamah: Record<PrayerKey, IqamahSetting> = {
  fajr: { type: 'offset', offsetMinutes: 20, fixedTime: '05:30', roundToNearest5: true },
  sunrise: { type: 'offset', offsetMinutes: 0, fixedTime: '', roundToNearest5: false },
  dhuhr: { type: 'offset', offsetMinutes: 15, fixedTime: '13:15', roundToNearest5: true },
  asr: { type: 'offset', offsetMinutes: 15, fixedTime: '16:45', roundToNearest5: true },
  maghrib: { type: 'offset', offsetMinutes: 10, fixedTime: '', roundToNearest5: false },
  isha: { type: 'offset', offsetMinutes: 15, fixedTime: '20:30', roundToNearest5: true },
};

const defaultTimeOverrides = {
  fajr: { enabled: false, adhanTime: '05:15', iqamahTime: '05:45' },
  sunrise: { enabled: false, adhanTime: '06:15' },
  dhuhr: { enabled: false, adhanTime: '12:45', iqamahTime: '13:15' },
  asr: { enabled: false, adhanTime: '16:30', iqamahTime: '17:00' },
  maghrib: { enabled: false, adhanTime: '18:15', iqamahTime: '18:25' },
  isha: { enabled: false, adhanTime: '19:45', iqamahTime: '20:15' },
};

export const DEFAULT_SETTINGS: MosqueSettings = {
  mosqueName: 'বান্দারবানী জামে মসজিদ',
  mosqueArabicName: 'مسجد بندرباني الجامع',
  hallName: 'মূল নামাজ কক্ষ',
  theme: 'classic-masjid-emerald',
  timeFormat: '12h',
  showSeconds: true,
  method: 'Karachi',
  juristic: 'Hanafi',
  highLatitudeRule: 'AngleBased',
  hijriOffsetDays: 0,
  location: {
    city: 'বান্দারবানি (পিন-৭২১৫০৪)',
    country: 'ঝাড়গ্রাম, পশ্চিমবঙ্গ, ভারত',
    latitude: 22.5057,
    longitude: 86.9922,
    timezone: 5.5,
    autoDetectTimezone: true,
    elevation: 85,
  },
  manualOffsets: {
    fajr: 0,
    sunrise: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  },
  reminders: defaultReminders,
  globalVolume: 0.85,
  soundMuted: false,
  iqamahSettings: defaultIqamah,
  jumuaAdhanTime: '12:30',
  jumuaKhutbahTime: '12:45',
  jumuaTime: '13:15',
  timeOverrides: defaultTimeOverrides,
  enablePreIqamahBeep: true,
  preIqamahMinutes: 2,
  salahDurationMinutes: 15,
  announcements: [
    'বান্দারবানী জামে মসজিদে স্বাগতম · অনুগ্রহ করে মসজিদে প্রবেশের পর মোবাইল ফোন সাইলেন্ট রাখুন।',
    'হাদিস শরীফ: "সর্বোত্তম আমল হলো ওয়াক্তমত নামাজ আদায় করা।" (সহীহ বুখারী)',
    'ইক্বামতের পূর্বে কাতার সোজা করুন এবং ফাঁকা জায়গা পূরণ করুন।',
    'পবিত্র জুমু\'আ: ১ম আযান ১২:৩০ · খুতবা ১২:৪৫ · জুমার জামাত ০১:১৫।',
    'প্রতিদিন আসরের নামাজের ২০ মিনিট পর কুরআন ও তাফসীর হালাকা অনুষ্ঠিত হয়।',
    'মসজিদ পরিচালনা ফান্ডে আপনার সামর্থ্য অনুযায়ী মুক্তহস্তে দান করুন।',
  ],
  showExtraTimes: true,
  imamName: 'হাফেজ মাওলানা মোঃ ক্বারী সাহেব',
  presidentName: 'জনাব মোঃ সভাপতি সাহেব',
  showLeadership: true,
};

const STORAGE_KEY = 'masjid_salah_board_settings_v1';

export function loadSettings(): MosqueSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    const loadedName =
      !parsed.mosqueName ||
      parsed.mosqueName === 'Masjid Al-Noor' ||
      parsed.mosqueName === 'BANDARBANI JAMA MASJID' ||
      parsed.mosqueName === 'বন্দরবানী জামে মসজিদ'
        ? DEFAULT_SETTINGS.mosqueName
        : parsed.mosqueName;
    const loadedArabic =
      !parsed.mosqueArabicName || parsed.mosqueArabicName === 'جامع النور'
        ? DEFAULT_SETTINGS.mosqueArabicName
        : parsed.mosqueArabicName;

    const isOldLocation =
      !parsed.location ||
      parsed.location.city === 'Makkah' ||
      parsed.location.city === 'مكة المكرمة' ||
      parsed.location.country === 'Saudi Arabia' ||
      parsed.location.country === 'المملكة العربية السعودية' ||
      parsed.location.city === 'বান্দরবান' ||
      parsed.location.city === 'My Local Mosque' ||
      parsed.location.country === 'Local';

    const loadedLocation = isOldLocation
      ? DEFAULT_SETTINGS.location
      : { ...DEFAULT_SETTINGS.location, ...(parsed.location || {}) };

    const mergedSettings: MosqueSettings = {
      ...DEFAULT_SETTINGS,
      ...parsed,
      mosqueName: loadedName,
      mosqueArabicName: loadedArabic,
      hallName: parsed.hallName === 'Main Prayer Hall' ? DEFAULT_SETTINGS.hallName : (parsed.hallName || DEFAULT_SETTINGS.hallName),
      announcements: (!parsed.announcements || parsed.announcements[0]?.includes('Welcome to'))
        ? DEFAULT_SETTINGS.announcements
        : parsed.announcements,
      jumuaAdhanTime: parsed.jumuaAdhanTime || DEFAULT_SETTINGS.jumuaAdhanTime,
      jumuaKhutbahTime: parsed.jumuaKhutbahTime || DEFAULT_SETTINGS.jumuaKhutbahTime,
      jumuaTime: parsed.jumuaTime || DEFAULT_SETTINGS.jumuaTime,
      timeOverrides: {
        ...DEFAULT_SETTINGS.timeOverrides,
        ...(parsed.timeOverrides || {}),
      },
      location: loadedLocation,
      reminders: { ...DEFAULT_SETTINGS.reminders, ...(parsed.reminders || {}) },
      iqamahSettings: { ...DEFAULT_SETTINGS.iqamahSettings, ...(parsed.iqamahSettings || {}) },
      manualOffsets: { ...DEFAULT_SETTINGS.manualOffsets, ...(parsed.manualOffsets || {}) },
      imamName: parsed.imamName !== undefined ? parsed.imamName : DEFAULT_SETTINGS.imamName,
      presidentName: parsed.presidentName !== undefined ? parsed.presidentName : DEFAULT_SETTINGS.presidentName,
      showLeadership: parsed.showLeadership !== undefined ? parsed.showLeadership : DEFAULT_SETTINGS.showLeadership,
    };

    if (isOldLocation) {
      saveSettings(mergedSettings);
    }

    return mergedSettings;
  } catch (err) {
    console.error('Failed to parse saved settings, falling back to defaults', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: MosqueSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings to localStorage', err);
  }
}
