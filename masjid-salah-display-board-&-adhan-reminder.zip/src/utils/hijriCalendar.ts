export interface HijriDateInfo {
  day: number;
  month: number;
  monthEnglish: string;
  monthArabic: string;
  monthBengali: string;
  year: number;
  formattedEnglish: string;
  formattedArabic: string;
  formattedBengali: string;
  isSpecialDay?: string;
  isSpecialDayBengali?: string;
}

export function toBengaliDigits(num: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return num.toString().replace(/[0-9]/g, (d) => bnDigits[parseInt(d, 10)]);
}

const HIJRI_MONTHS = [
  { en: 'Muharram', ar: 'المُحَرَّم', bn: 'মহররম' },
  { en: 'Safar', ar: 'صَفَر', bn: 'সফর' },
  { en: "Rabi' al-Awwal", ar: 'رَبِيع الأَوَّل', bn: 'রবিউল আউয়াল' },
  { en: "Rabi' al-Thani", ar: 'رَبِيع الآخِر', bn: 'রবিউস সানি' },
  { en: 'Jumada al-Awwal', ar: 'جُمَادَى الأُولَى', bn: 'জমাদিউল আউয়াল' },
  { en: 'Jumada al-Thani', ar: 'جُمَادَى الآخِرَة', bn: 'জমাদিউস সানি' },
  { en: 'Rajab', ar: 'رَجَب', bn: 'রজব' },
  { en: "Sha'ban", ar: 'شَعْبَان', bn: 'শাবান' },
  { en: 'Ramadan', ar: 'رَمَضَان', bn: 'রমজান' },
  { en: 'Shawwal', ar: 'شَوَّال', bn: 'শাওয়াল' },
  { en: "Dhu al-Qi'dah", ar: 'ذُو القَعْدَة', bn: 'জ্বিলকদ' },
  { en: 'Dhu al-Hijjah', ar: 'ذُو الحِجَّة', bn: 'জ্বিলহজ্জ' },
];

export const BENGALI_WEEKDAYS = [
  'রবিবার',
  'সোমবার',
  'মঙ্গলবার',
  'বুধবার',
  'বৃহস্পতিবার',
  'শুক্রবার (পবিত্র জুমাবার)',
  'শনিবার',
];

export const BENGALI_GREGORIAN_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

export function formatBengaliGregorianDate(date: Date): string {
  const weekday = BENGALI_WEEKDAYS[date.getDay()];
  const day = toBengaliDigits(date.getDate());
  const month = BENGALI_GREGORIAN_MONTHS[date.getMonth()];
  const year = toBengaliDigits(date.getFullYear());
  return `${weekday}, ${day} ${month} ${year} খ্রি.`;
}

/**
 * Converts a Gregorian Date to an adjusted Hijri date using Kuwaiti/Umm-al-Qura algorithm
 * with customizable offset days for local moon-sighting.
 */
export function getHijriDate(date: Date, offsetDays: number = 0): HijriDateInfo {
  const adjusted = new Date(date);
  adjusted.setDate(adjusted.getDate() + offsetDays);

  const day = adjusted.getDate();
  const month = adjusted.getMonth();
  const year = adjusted.getFullYear();

  let m = month + 1;
  let y = year;
  if (m < 3) {
    y -= 1;
    m += 12;
  }

  let a = Math.floor(y / 100);
  let b = 2 - a + Math.floor(a / 4);
  if (y < 1583) b = 0;
  if (y === 1582) {
    if (m > 10) b = -10;
    if (m === 10) {
      b = 0;
      if (day > 4) b = -10;
    }
  }

  const jd =
    Math.floor(365.25 * (y + 4716)) +
    Math.floor(30.6001 * (m + 1)) +
    day +
    b -
    1524;

  const bjd = jd - 1948440 + 10632;
  const n = Math.floor((bjd - 1) / 10631);
  const remainder = bjd - 10631 * n + 354;
  const j =
    Math.floor((10985 - remainder) / 5316) *
      Math.floor((50 * remainder) / 17719) +
    Math.floor(remainder / 5670) * Math.floor((43 * remainder) / 15238);
  const remainder2 =
    remainder -
    Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) -
    Math.floor(j / 16) * Math.floor((15238 * j) / 43) +
    29;

  const hMonth = Math.floor((24 * remainder2) / 709);
  const hDay = remainder2 - Math.floor((709 * hMonth) / 24);
  const hYear = 30 * n + j - 30;

  const safeMonthIndex = Math.max(0, Math.min(11, hMonth - 1));
  const monthInfo = HIJRI_MONTHS[safeMonthIndex] || HIJRI_MONTHS[0];

  let specialDay: string | undefined;
  let specialDayBn: string | undefined;
  if (hMonth === 9) {
    specialDay = 'Ramadan Mubarak';
    specialDayBn = 'পবিত্র মাহে রমজান মোবারক';
  } else if (hMonth === 10 && hDay === 1) {
    specialDay = 'Eid al-Fitr';
    specialDayBn = 'পবিত্র ঈদুল ফিতর';
  } else if (hMonth === 12 && hDay === 10) {
    specialDay = 'Eid al-Adha';
    specialDayBn = 'পবিত্র ঈদুল আজহা';
  } else if (hMonth === 12 && hDay === 9) {
    specialDay = 'Day of Arafah';
    specialDayBn = 'পবিত্র আরাফার দিন';
  } else if (hMonth === 1 && hDay === 10) {
    specialDay = 'Day of Ashura';
    specialDayBn = 'পবিত্র আশুরা';
  }

  const bnDay = toBengaliDigits(hDay);
  const bnYear = toBengaliDigits(hYear);

  return {
    day: hDay,
    month: hMonth,
    monthEnglish: monthInfo.en,
    monthArabic: monthInfo.ar,
    monthBengali: monthInfo.bn,
    year: hYear,
    formattedEnglish: `${hDay} ${monthInfo.en} ${hYear} AH`,
    formattedArabic: `${hDay} ${monthInfo.ar} ${hYear} هـ`,
    formattedBengali: `${bnDay} ${monthInfo.bn} ${bnYear} হিজরি`,
    isSpecialDay: specialDay,
    isSpecialDayBengali: specialDayBn,
  };
}
